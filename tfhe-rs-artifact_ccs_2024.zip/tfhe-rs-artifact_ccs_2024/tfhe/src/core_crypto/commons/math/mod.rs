//! A module containing general mathematical tools.

pub mod decomposition;
pub mod random;
pub mod torus;
