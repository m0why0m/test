#include <mosfhet.h>
#include <time.h>
#include "function.h"


int main(int argc, char const *argv[]) {
  /* code */

  const uint32_t N = 2048, n = 2048, k = 1, h = 42, hN = 256;
  const uint32_t l_bsk = 1, B_bsk = 23, l_auk = 2, B_auk = 15;
  const double key_sigma = 2.989040792967434e-8, key_sigma_N = 2.2148688116005568e-16;
  int pre = 2;//
  int t = 5, base_bit = 3;

  printf("INIT: Preparing for secret key ... ");
  TRLWE_Key rlwe_key_n = trlwe_new_binary_key_with_hw_balance(n, k, h, key_sigma);
  //TRLWE_Key rlwe_key_n = trlwe_alloc_key(n, k, key_sigma);
  //for (size_t i = 0;i<n;i++) rlwe_key_n->s[0]->coeffs[i]=0;
  //rlwe_key_n->s[0]->coeffs[0]=1;
  //rlwe_key_n->s[0]->coeffs[1]=1;
  //rlwe_key_n->s[0]->coeffs[2]=1;
  //polynomial_torus_to_DFT(rlwe_key_n->s_dft[0], rlwe_key_n->s[0]);

  TRLWE_Key rlwe_key_N = trlwe_new_binary_key_with_hw(N, k, hN, key_sigma_N);
  //TRLWE_Key rlwe_key_N = trlwe_alloc_key(N, k, key_sigma);
  //for (size_t i = 0;i<n;i++) rlwe_key_N->s[0]->coeffs[i]=0;
  //rlwe_key_N->s[0]->coeffs[0]=1;
  //rlwe_key_N->s[0]->coeffs[1]=1;
  //rlwe_key_N->s[0]->coeffs[2]=1;
  //polynomial_torus_to_DFT(rlwe_key_N->s_dft[0], rlwe_key_N->s[0]);
  printf("complete.\n");

  printf("INIT: Preparing for RLWE(m) ... ");
  srandom(time(NULL));
  TorusPolynomial m = polynomial_new_torus_polynomial(n);
  for(size_t i = 0;i < n;i++) {
     uint32_t mi = random() % ((1 << pre)/2);
     m->coeffs[i] = int2torus(mi, pre);
  }
  TRLWE rlwe = trlwe_new_sample_(m, rlwe_key_n);
  printf("complete.\n");

  printf("m(x) = (");
  for (size_t i = 0; i < 8; i++) printf("%lu, ", torus2int(m->coeffs[i], pre));
  printf(" ... ");
  for (size_t i = n - 9; i < n; i++) printf("%lu, ", torus2int(m->coeffs[i], pre));
  printf(")\n");

  printf("INIT: Preparing for testP ... ");
  TorusPolynomial testP = polynomial_new_torus_polynomial(N);
    for (size_t j = 0; j < N; j++) {
      uint64_t coe = (int)round((double)(j * (1 << pre)) / (double)(2 * N));
      uint64_t ind = N - j - 1;// + (N / (1 << pre));
      //Torus times = 1 << (sizeof(Torus) * 8 - (1 << pre));
      if (ind < N) {
	testP->coeffs[ind % N] = int2torus(-coe, pre);
      } else {
	testP->coeffs[ind % N] = int2torus(coe, pre);
      }
    }

  printf("complete.\n");

  printf("Preparing for key switch key ... ");
  TLWE_Key lwe_key = tlwe_alloc_key(N, 0);
  trlwe_extract_tlwe_key(lwe_key, rlwe_key_N);
  TRLWE_KS_Key ks_key = trlwe_new_full_packing_KS_key(rlwe_key_N, lwe_key, t, base_bit);
  free_tlwe_key(lwe_key);
  printf("complete.\n");


  printf("Preparing for auk ... ");
  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key_N, true, l_auk, B_auk);
  printf("complete.\n");

  printf("INIT: Preparing for bootstrapping key ... ");
  TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key_N, l_bsk, B_bsk);

  TRGSW rgsw_enc_0 = trgsw_new_sample(0, rgsw_key); TRGSW rgsw_enc_1 = trgsw_new_sample(1, rgsw_key);
  TRGSW tau_rgsw_enc_0 = tau_trgsw_new_sample(0, rgsw_key); TRGSW tau_rgsw_enc_1 = tau_trgsw_new_sample(1, rgsw_key);

  TRGSW_DFT rgsw_enc_0_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  TRGSW_DFT rgsw_enc_1_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  TRGSW_DFT tau_rgsw_enc_0_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  TRGSW_DFT tau_rgsw_enc_1_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);

  trgsw_to_DFT(rgsw_enc_0_DFT, rgsw_enc_0); trgsw_to_DFT(rgsw_enc_1_DFT, rgsw_enc_1);
  trgsw_to_DFT(tau_rgsw_enc_0_DFT, tau_rgsw_enc_0); trgsw_to_DFT(tau_rgsw_enc_1_DFT, tau_rgsw_enc_1);

  TRGSW_DFT *bsk[4][4] = {NULL};
  bsk[0][0] = &rgsw_enc_0_DFT; bsk[0][1] = &rgsw_enc_0_DFT; bsk[0][2] = &rgsw_enc_0_DFT; bsk[0][3] = &rgsw_enc_1_DFT;
  bsk[1][0] = &rgsw_enc_1_DFT; bsk[1][1] = &rgsw_enc_0_DFT; bsk[1][2] = &rgsw_enc_0_DFT; bsk[1][3] = &rgsw_enc_0_DFT;
  bsk[2][0] = &rgsw_enc_0_DFT; bsk[2][1] = &rgsw_enc_1_DFT; bsk[2][2] = &rgsw_enc_0_DFT; bsk[2][3] = &rgsw_enc_0_DFT;
  bsk[3][0] = &rgsw_enc_0_DFT; bsk[3][1] = &rgsw_enc_0_DFT; bsk[3][2] = &rgsw_enc_1_DFT; bsk[3][3] = &rgsw_enc_0_DFT;

  TRGSW_DFT *tau_bsk[4][4] = {NULL};
  tau_bsk[0][0] = &tau_rgsw_enc_0_DFT; tau_bsk[0][1] = &tau_rgsw_enc_0_DFT; tau_bsk[0][2] = &tau_rgsw_enc_0_DFT; tau_bsk[0][3] = &rgsw_enc_1_DFT;
  tau_bsk[1][0] = &tau_rgsw_enc_1_DFT; tau_bsk[1][1] = &tau_rgsw_enc_0_DFT; tau_bsk[1][2] = &tau_rgsw_enc_0_DFT; tau_bsk[1][3] = &rgsw_enc_0_DFT;
  tau_bsk[2][0] = &tau_rgsw_enc_0_DFT; tau_bsk[2][1] = &tau_rgsw_enc_1_DFT; tau_bsk[2][2] = &tau_rgsw_enc_0_DFT; tau_bsk[2][3] = &rgsw_enc_0_DFT;
  tau_bsk[3][0] = &tau_rgsw_enc_0_DFT; tau_bsk[3][1] = &tau_rgsw_enc_0_DFT; tau_bsk[3][2] = &tau_rgsw_enc_1_DFT; tau_bsk[3][3] = &rgsw_enc_0_DFT;

  free_trgsw(rgsw_enc_0); free_trgsw(rgsw_enc_1); free_trgsw(tau_rgsw_enc_0); free_trgsw(tau_rgsw_enc_1);
  printf("complete.\n");

  printf("INIT: Decomposing secret key ... ");
  uint32_t diffnum = 0;
  int *diff = (int *)malloc((n + 1) * sizeof(int));
  int *diff0 = (int *)malloc((n + 1) * sizeof(int));
  memset(diff0, 0, (n + 1));
  memset(diff, 0, (n + 1));
  for (size_t i = 0; i < n; i++) {
    if (rlwe_key_n->s[0]->coeffs[i] == 1) {
      diff0[diffnum] = i;
      diffnum++;
    }
  }

  diff[0] = diff0[0];
  for (size_t i = 1; i < diffnum; i++) {
    diff[i] = diff0[i] - diff0[i - 1];
  }
  diff[diffnum] = diff0[diffnum - 1];
  diffnum++;
  free(diff0);

  uint32_t all_lv[100] = {0};
  int **all_rows = (int **)malloc(sizeof(int *) * 100);
  for (size_t i = 0; i < 100; i++) all_rows[i] = (int *)malloc(sizeof(int) * 100);
  for (size_t i = 0; i < diffnum; i++) {
    while (diff[i] > 0) {
      all_rows[i][all_lv[i]++] = diff[i] % 4;
      diff[i] >>= 2;
    }
    //all_lv[i] <<= 1;
  }
  printf("complete\n");
  bsk_head_list all_list = create_bsk_head_list(diffnum, all_lv, all_rows, bsk, tau_bsk);
  for (size_t i = 0; i < diffnum; i++) {
    all_lv[i] <<= 1;
  }
  
  printf("complete\n");



  clock_t start, end;
  double ms_time;
  printf("Full packing case ...\n");
  start = clock();

  TRLWE out = fullCase(testP, rlwe, rlwe_key_N, all_list, N, n, k, h, l_bsk, B_bsk, pre, 
diffnum, all_lv, t, base_bit, ks_key, auk);
  end = clock();
  printf("complete.\n");

  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);

  //full packing verify
  TorusPolynomial plain = polynomial_new_torus_polynomial(N);
  trlwe_phase(plain, out, rlwe_key_N);

  printf("M(x) = (");
  for (size_t i = 0; i < 8; i++) printf("%lu, ", torus2int(plain->coeffs[i], pre));
  printf(" ... ");
  for (size_t i = N - 9; i < N; i++) printf("%lu, ", torus2int(plain->coeffs[i], pre));
  printf(")\n");

  int error = 0;
  for (size_t i = 0; i < N; i++) {
    if (torus2int(plain->coeffs[i], pre) != torus2int(m->coeffs[i], pre)) {
      error++;
    }
  }
  printf("The number of coefficient errors: %d\n", error);
  free_trlwe(out);
  free_polynomial(plain);

  printf("Cleaning data ...");
  delete_bsk_head_list(all_list);
  free(diff);
  free_trlwe(rlwe);

  free_polynomial(m);
  free_polynomial(testP);


  free_trlwe_key(rlwe_key_n);
  free_trlwe_key(rlwe_key_N);
  free_trgsw_key(rgsw_key);
  
  free_trlwe_ks_key(ks_key);
  for (size_t i = 0; i < N; i++) free_trlwe_ks_key(auk[i]);
  free(auk);
  for (size_t i = 0; i < 100; i++) free(all_rows[i]);
  free(all_rows);

  free_trgsw(rgsw_enc_0_DFT);
  free_trgsw(rgsw_enc_1_DFT);
  free_trgsw(tau_rgsw_enc_0_DFT);
  free_trgsw(tau_rgsw_enc_1_DFT);

  printf("complete.\n");

  return 0;
}



















