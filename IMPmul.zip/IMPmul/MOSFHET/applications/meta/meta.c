#include <mosfhet.h>
#include <time.h>
#include "function.h"

int main(int argc, char const *argv[]) {
  /* code */
  const uint32_t N = 2048, n = 760, k = 1, h = 256, hN = 512;
  const uint32_t l_brk = 2, B_brk = 17, l_auk = 2, B_auk = 17;
  const uint32_t l_rvk = 2, B_rvk = 17, l = 4, B = 4;
  const double key_sigma = pow(2,-17), key_sigma_N = pow(2,-53);
  int pre = 5;

  TLWE_Key lwe_key = tlwe_new_binary_key_with_hw(n, h, key_sigma);
  TRLWE_Key rlwe_key = trlwe_new_binary_key_with_hw_balance(N, k, hN, 16, key_sigma_N);
  TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key, l_brk, B_brk);
  srandom(time(NULL));
  uint64_t mi = random() % ((1 << pre) / 2);
  Torus m = int2torus(mi, pre);
  TLWE ct = tlwe_new_sample(m, lwe_key);

  Bootstrap_Key brk = new_bootstrap_key(rgsw_key, lwe_key, 1);
  TRLWE_Key s2 = trlwe_alloc_key(N, k, key_sigma_N);
  polynomial_naive_mul_torus(s2->s[0], rlwe_key->s[0], rlwe_key->s[0]);
  polynomial_torus_to_DFT(s2->s_dft[0], s2->s[0]);
  TRLWE_KS_Key rvk = trlwe_new_KS_key(rlwe_key, s2, l_rvk, B_rvk);
  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key, true, l_auk, B_auk);
  free_trlwe_key(s2);

  TorusPolynomial testP = polynomial_new_torus_polynomial(N);
  for (size_t j = 0; j < N; j++) {
    uint64_t coe = ((int)round((double)(j * (1 << pre)) / (double)(2 * N))) % ((1 << pre) >> 1);
    uint64_t ind = N - j - 1;
    if (ind < N) {
      testP->coeffs[ind % N] = int2torus(-coe, pre);
    } else {
      testP->coeffs[ind % N] = int2torus(coe, pre);
    }
  }
  TRLWE c_testP = trlwe_new_sample(testP, rlwe_key);
  clock_t start, end;
  double ms_time;
  start = clock();

  TRGSW c_rgsw = meta(ct, brk, auk, rvk, N, n, k, B, l, pre);
  TRLWE_DFT res0 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE res = trlwe_alloc_new_sample(k, N);
  TRGSW_DFT c_dft = trgsw_alloc_new_DFT_sample(l, B, k, N);
  TLWE out = tlwe_alloc_sample(N);

  trgsw_to_DFT(c_dft, c_rgsw);
  trgsw_mul_trlwe_DFT(res0, c_testP, c_dft);
  trlwe_from_DFT(res, res0);
  trlwe_extract_tlwe(out, res, 0);

  free_trlwe(res);
  free_trlwe(res0);
  free_trgsw(c_rgsw);
  free_trgsw(c_dft);

  end = clock();
  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);

  //verify
  TLWE_Key out_key = tlwe_alloc_key(N, 0.0);
  trlwe_extract_tlwe_key(out_key, rlwe_key);
  printf("expacted = %lu, result = %lu\n", mi, torus2int(tlwe_phase(out, out_key), pre));

  free_tlwe(out);
  free_trlwe(c_testP);
  free_polynomial(testP);
  free_tlwe_key(lwe_key);
  free_tlwe_key(out_key);
  free_trlwe_key(rlwe_key);
  free_trgsw_key(rgsw_key);

  for (size_t i = 0; i < N; i++) {
    free_trlwe_ks_key(auk[i]);
  }
  free(auk);
  free_trlwe_ks_key(rvk);
  free_bootstrap_key(brk);

  return 0;
}



















