#include <mosfhet.h>
#include <time.h>
#include "function.h"

uint64_t func(uint64_t a1, uint64_t a2, uint64_t a3, uint64_t a4, uint32_t p) {
  return (a1 + a2 + a3 + a4) % (p >> 1);
}

uint64_t func2(uint64_t a1, uint64_t a2, uint64_t a3, uint32_t p) {
  return (a1 + a2 + a3) % (p >> 1);
}

uint64_t func3(uint64_t a1, uint64_t a2, uint32_t p) {
  return (a1 + a2) % (p >> 1);
}

int main(int argc, char const *argv[]) {
  /* code */
  const uint32_t N = 2048, n = 760, k = 1, h = 5, hN = 5;
  const uint32_t l_brk = 2, B_brk = 17, l_auk = 2, B_auk = 17;
  const uint32_t l_rvk = 2, B_rvk = 17, l = 4, B = 4;
  const double key_sigma = pow(2,-17), key_sigma_N = pow(2,-53);
  int pre = 2;

  const uint32_t beta = 2;

  uint32_t p = 1 << pre;
  uint32_t testP_num = fast_pow(p >> 1, beta - 1);
  int t = 5, base_bit = 3;

  TLWE_Key lwe_key = tlwe_new_binary_key_with_hw(n, h, key_sigma);
  TRLWE_Key rlwe_key = trlwe_new_binary_key_with_hw_balance(N, k, hN, 16, key_sigma_N);
  TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key, l_brk, B_brk);
  srandom(time(NULL));
  uint64_t mi = random() % ((1 << pre) / 2);
  Torus m = int2torus(mi, pre);
  TLWE ct = tlwe_new_sample(m, lwe_key);

  Bootstrap_Key brk = new_bootstrap_key(rgsw_key, lwe_key, 1);
  TRLWE_Key s2 = trlwe_alloc_key(N, k, key_sigma_N);
  polynomial_naive_mul_torus(s2->s[0], rlwe_key->s[0], rlwe_key->s[0]);
  polynomial_torus_to_DFT(s2->s_dft[0], s2->s[0]);
  TRLWE_KS_Key rvk = trlwe_new_KS_key(rlwe_key, s2, l_rvk, B_rvk);
  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key, true, l_auk, B_auk);
  free_trlwe_key(s2);


  //printf("Preparing for key switch key ... ");
  TLWE_Key lwe_key2 = tlwe_alloc_key(N, 0);
  trlwe_extract_tlwe_key(lwe_key2, rlwe_key);
  TRLWE_KS_Key ks_key = trlwe_new_full_packing_KS_key(rlwe_key, lwe_key2, t, base_bit);
  free_tlwe_key(lwe_key2);
  //printf("complete.\n");





  TorusPolynomial testP_ = polynomial_new_torus_polynomial(N);
  for (size_t j = 0; j < N; j++) {
    uint64_t coe = ((int)round((double)(j * (1 << pre)) / (double)(2 * N))) % ((1 << pre) >> 1);
    uint64_t ind = N - j - 1;
    if (ind < N) {
      testP_->coeffs[ind % N] = int2torus(-coe, pre);
    } else {
      testP_->coeffs[ind % N] = int2torus(coe, pre);
    }
  }
  TRLWE c_testP = trlwe_new_sample(testP_, rlwe_key);



  //testP f() value
  uint64_t **f = (uint64_t **)malloc(sizeof(uint64_t *) * testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    f[i] = (uint64_t *)malloc(sizeof(uint64_t *) * N);
  }


  //beta = 2, p = 4, testP_num = 2
  //[1,1,0,0],[0,0,1,1]
  for (size_t i = 0; i < N / 2; i++) {
    f[0][i] = 1; f[1][i] = 0;
  }
  for (size_t i = N / 2; i < N; i++) {
    f[0][i] = 0; f[1][i] = 1;
  }


/*
  //beta = 3, p = 4, testP_num = 4
  //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0]
  for (size_t i = 0; i < N / 2; i++) {
    f[0][i] = f[3][i] = 1; f[1][i] = f[2][i] = 0;
  }
  for (size_t i = N / 2; i < N; i++) {
    f[0][i] = f[3][i] = 0; f[1][i] = f[2][i] = 1;
  }
*/

/*
  //beta = 4, p = 4, testP_num = 8
  //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0],[0,0,1,1],[1,1,0,0],[1,1,0,0],[0,0,1,1]
  for (size_t i = 0; i < N / 2; i++) {
    f[0][i] = f[3][i] = f[5][i] = f[6][i] = 1;
    f[1][i] = f[2][i] = f[4][i] = f[7][i] = 0;
  }
  for (size_t i = N / 2; i < N; i++) {
    f[0][i] = f[3][i] = f[5][i] = f[6][i] = 0;
    f[1][i] = f[2][i] = f[4][i] = f[7][i] = 1;
  }
*/

/*
  //beta = 2, p = 32, testP_num = 16
  //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
  for (size_t i = 0; i < 16; i++) {
    for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
      f[0][j] = 15 - i;
    }
  }

  for (size_t i = 0; i < 16; i++) {//+i
    for (size_t ii = 0; ii < N; ii++) {
      f[i][ii] = func3(f[0][ii], i, p);
    }
  }
*/

/*
  //beta = 3, p = 32, testP_num = 256
  //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
  for (size_t i = 0; i < 16; i++) {
    for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
      f[0][j] = 15 - i;
    }
  }

  for (size_t i = 0; i < 16; i++) {//+i
    for (size_t j = 0; j < 16; j++) {//+j
      for (size_t ii = 0; ii < N; ii++) {
        f[16*i+j][ii] = func2(f[0][ii], i, j, p);
      }
    }
  }
*/

/*
  //beta = 4, p = 32, testP_num = 4096
  //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
  for (size_t i = 0; i < 16; i++) {
    for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
      f[0][j] = 15 - i;
    }
  }

  for (size_t i = 0; i < 16; i++) {//+i
    for (size_t j = 0; j < 16; j++) {//+j
      for (size_t z = 0; z < 16; z++) {//+z
        for (size_t ii = 0; ii < N; ii++) {
          f[256*i+16*j+z][ii] = func(f[0][ii], i, j, z, p);
        }
      }
    }
  }

*/

  TorusPolynomial *testP = polynomial_new_array_of_torus_polynomials(N, testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    for (size_t j = 0; j < N; j++) {
      testP[i]->coeffs[j] = int2torus(-f[i][j], pre);
    }
  }
  //printf("complete.\n");








  clock_t start, end;
  double ms_time;
  start = clock();
  TRGSW *c_rgsw = (TRGSW *)malloc(sizeof(TRGSW)*beta);
  for (size_t i = 0; i < beta; i++) {
    c_rgsw[i] = meta(ct, brk, auk, rvk, N, n, k, B, l, pre);
  }
  TRLWE result = TEP(c_rgsw, testP, ks_key, auk, rlwe_key, N, k, l, B, beta, pre, testP_num);

  end = clock();
  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);

  //TEP verify
  TorusPolynomial plain = polynomial_new_torus_polynomial(N);
  trlwe_phase(plain, result, rlwe_key);
  printf("m = %lu, result = %lu\n", mi, torus2int(plain->coeffs[0], pre));
  free_polynomial(plain);


  free_trlwe(c_testP);
  for (size_t i = 0; i < beta; i++) free_trgsw(c_rgsw[i]);
  free(c_rgsw);
  free_polynomial(testP_);
  free_tlwe_key(lwe_key);
  free_trlwe_key(rlwe_key);
  free_trgsw_key(rgsw_key);

  free_trlwe_ks_key(rvk);
  free_bootstrap_key(brk);

  free_polynomial(result);
  free_array_of_polynomials(testP, testP_num);

  free_trlwe_ks_key(ks_key);


  for (size_t i = 0; i < N; i++) free_trlwe_ks_key(auk[i]);
  free(auk);

  return 0;
}


















