#include <mosfhet.h>
#include <time.h>
#include "function.h"

TLWE FDFB(TLWE ct, Bootstrap_Key brk, TRLWE_KS_Key *auk, TRLWE_KS_Key rvk,
TorusPolynomial testP_sign, TRLWE_Key rlwe_key, TLWE_KS_Key ks_key,
TorusPolynomial testP0,TorusPolynomial testP0_,
TorusPolynomial testP1,
uint32_t N, uint32_t n, uint32_t k, uint32_t B, uint32_t l, int pre) {
  int p = 1 << pre;
  TRGSW_DFT c_dft = trgsw_alloc_new_DFT_sample(l, B, k, N);
  TRLWE acc = trlwe_alloc_new_sample(k, N);
  TRLWE_DFT temp = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE temp2 = trlwe_alloc_new_sample(k, N);

  ct->b += UINT64_MAX / (2 * p);
  TRGSW c_rgsw = meta(ct, brk, auk, rvk, N, n, k, B, l, pre);
  trgsw_to_DFT(c_dft, c_rgsw);
  trgsw_mul_trlwe_b_DFT(temp, testP_sign, c_dft);
  trlwe_from_DFT(temp2, temp);
  temp2->b->coeffs[0] += UINT64_MAX / (2 * p);
  homo_trace(acc, temp2, 1, auk);


  TRLWE_DFT acc_dft = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT accres_dft = trlwe_alloc_new_DFT_sample(k, N);
  DFT_Polynomial poly_dft = polynomial_new_DFT_polynomial(N);

  polynomial_subto_torus_polynomial(testP1, testP0_);
  polynomial_torus_to_DFT(poly_dft, testP1);
  trlwe_to_DFT(acc_dft, acc);
  
  trlwe_DFT_mul_by_polynomial(accres_dft, acc_dft, poly_dft);

  trlwe_from_DFT(acc, accres_dft);

  polynomial_addto_torus_polynomial(acc->b, testP0);


  trgsw_mul_trlwe_DFT(temp, acc, c_dft);
  trlwe_from_DFT(temp2, temp);

  TLWE result0 = tlwe_alloc_sample(N);
  TLWE result = tlwe_alloc_sample(N);
  trlwe_extract_tlwe(result0, temp2, 0);
  tlwe_keyswitch(result, result0, ks_key);

  return result;
}

int main(int argc, char const *argv[]) {
  /* code */
  const uint32_t N = 2048, n = 512, k = 1, h = 3, hN = 256;
  const uint32_t l_brk = 2, B_brk = 17, l_auk = 2, B_auk = 17;
  const uint32_t l_rvk = 2, B_rvk = 17, l = 4, B = 4;
  const double key_sigma = pow(2,-17), key_sigma_N = pow(2,-53);
  //const double key_sigma = 0.0, key_sigma_N = 0.0;
  int pre = 4;
  const int t = 3, base_bit = 5;

  int p = 1 << pre;

  TLWE_Key lwe_key = tlwe_new_binary_key_with_hw(n, h, key_sigma);
  TRLWE_Key rlwe_key = trlwe_new_binary_key_with_hw_balance(N, k, hN, 16, key_sigma_N);
  TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key, l_brk, B_brk);

  srandom(time(NULL));
  uint64_t mi = random() % ((1 << pre));
  Torus m = int2torus(mi, pre);
  TLWE ct = tlwe_new_sample(m, lwe_key);

  Bootstrap_Key brk = new_bootstrap_key(rgsw_key, lwe_key, 1);
  TRLWE_Key s2 = trlwe_alloc_key(N, k, key_sigma_N);
  polynomial_naive_mul_torus(s2->s[0], rlwe_key->s[0], rlwe_key->s[0]);
  polynomial_torus_to_DFT(s2->s_dft[0], s2->s[0]);
  TRLWE_KS_Key rvk = trlwe_new_KS_key(rlwe_key, s2, l_rvk, B_rvk);
  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key, true, l_auk, B_auk);
  free_trlwe_key(s2);


  TLWE_Key ex_key = tlwe_alloc_key(N, 0.0);
  trlwe_extract_tlwe_key(ex_key, rlwe_key);

  TLWE_KS_Key ks_key = tlwe_new_KS_key(lwe_key, ex_key, t, base_bit);


  TorusPolynomial testP_sign = polynomial_new_torus_polynomial(N);
  for (size_t j = 0; j < N; j++) {
    testP_sign->coeffs[j] = UINT64_MAX / (2 * p);
  }

  TorusPolynomial testP0 = polynomial_new_torus_polynomial(N);
  for (size_t j = 0; j < N; j++) {
    uint64_t coe = ((int)round((double)(j * (1 << pre)) / (double)(2 * N))) % ((1 << pre) >> 1);
    uint64_t ind = N - j - 1 - N / p;
    if (ind < N) {
      testP0->coeffs[ind % N] = int2torus(-coe, pre);
    } else {
      testP0->coeffs[ind % N] = int2torus(coe, pre);
    }
  }

  TorusPolynomial testP0_ = polynomial_new_torus_polynomial(N);
  for (size_t j = 0; j < N; j++) {
    uint64_t coe = ((int)round((double)(j * (1 << pre)) / (double)(2 * N))) % ((1 << pre) >> 1);
    uint64_t ind = N - j - 1 - N / p;
    if (ind < N) {
      testP0_->coeffs[ind % N] = -coe;
    } else {
      testP0_->coeffs[ind % N] = coe;
    }
  }

  TorusPolynomial testP1 = polynomial_new_torus_polynomial(N);
  for (size_t j = 0; j < N; j++) {
    uint64_t coe = ((int)round((double)(j * (1 << pre)) / (double)(2 * N))) % ((1 << pre) >> 1) + p / 2;
    uint64_t ind = N - j - 1 - N / p;
    testP1->coeffs[ind % N] = coe;
  }
  clock_t start, end;
  double ms_time;
  start = clock();

  TLWE result = FDFB(ct, brk, auk, rvk, testP_sign, rlwe_key, ks_key, testP0, testP0_, testP1,
N, n, k, B, l, pre);

  end = clock();
  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);


  printf("expacted = %lu, result = %lu\n", mi, torus2int(tlwe_phase(result, lwe_key), pre));


  //free_trlwe(res);
  //free_trlwe(c_testP);
  free_polynomial(testP_sign);
  free_tlwe_key(lwe_key);
  free_trlwe_key(rlwe_key);
  free_trgsw_key(rgsw_key);

  for (size_t i = 0; i < N; i++) {
    free_trlwe_ks_key(auk[i]);
  }
  free(auk);
  free_trlwe_ks_key(rvk);
  free_bootstrap_key(brk);

  return 0;
}




































