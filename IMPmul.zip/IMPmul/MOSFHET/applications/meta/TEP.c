#include <mosfhet.h>
#include <time.h>
#include "function.h"

uint64_t func(uint64_t a1, uint64_t a2, uint64_t a3, uint64_t a4, uint32_t p) {
  return (a1 + a2 + a3 + a4) % (p >> 1);
}

uint64_t func2(uint64_t a1, uint64_t a2, uint64_t a3, uint32_t p) {
  return (a1 + a2 + a3) % (p >> 1);
}

uint64_t func3(uint64_t a1, uint64_t a2, uint32_t p) {
  return (a1 + a2) % (p >> 1);
}

int main(int argc, char const *argv[]) {

  const uint32_t N = 2048, beta = 4, k = 1, h = 128;
  const uint32_t l = 2, B = 20, l_auk = 1, B_auk = 23;
  const double key_sigma = 0;
  int pre = 5;
  uint32_t p = 1 << pre;
  uint32_t testP_num = fast_pow(p >> 1, beta - 1);
  int t = 5, base_bit = 3;

  //printf("INIT: Preparing for secret key ... ");
  TRLWE_Key rlwe_key = trlwe_new_binary_key_with_hw(N, k, h, key_sigma);
  TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key, l, B);
  //printf("complete.\n");

  //printf("INIT: Preparing for RGSW(X^m) ... ");
  srandom(time(NULL));
  TRGSW *c_rgsw = trgsw_alloc_new_sample_array(beta, l, B, k, N);
  trgsw_monomial_sample(c_rgsw[0], 1, 1 * N / (p >> 1) , rgsw_key);
  trgsw_monomial_sample(c_rgsw[1], 1, 1 * N / (p >> 1) , rgsw_key);
  trgsw_monomial_sample(c_rgsw[2], 1, 1 * N / (p >> 1) , rgsw_key);
  trgsw_monomial_sample(c_rgsw[3], 1, 4 * N / (p >> 1) , rgsw_key);
  //printf("complete.\n");


  //printf("Preparing for testP ... ");
  //testP f() value
  uint64_t **f = (uint64_t **)malloc(sizeof(uint64_t *) * testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    f[i] = (uint64_t *)malloc(sizeof(uint64_t *) * N);
  }

/*
  //beta = 2, p = 4, testP_num = 2
  //[1,1,0,0],[0,0,1,1]
  for (size_t i = 0; i < N / 2; i++) {
    f[0][i] = 1; f[1][i] = 0;
  }
  for (size_t i = N / 2; i < N; i++) {
    f[0][i] = 0; f[1][i] = 1;
  }
*/

/*
  //beta = 3, p = 4, testP_num = 4
  //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0]
  for (size_t i = 0; i < N / 2; i++) {
    f[0][i] = f[3][i] = 1; f[1][i] = f[2][i] = 0;
  }
  for (size_t i = N / 2; i < N; i++) {
    f[0][i] = f[3][i] = 0; f[1][i] = f[2][i] = 1;
  }
*/

/*
  //beta = 4, p = 4, testP_num = 8
  //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0],[0,0,1,1],[1,1,0,0],[1,1,0,0],[0,0,1,1]
  for (size_t i = 0; i < N / 2; i++) {
    f[0][i] = f[3][i] = f[5][i] = f[6][i] = 1;
    f[1][i] = f[2][i] = f[4][i] = f[7][i] = 0;
  }
  for (size_t i = N / 2; i < N; i++) {
    f[0][i] = f[3][i] = f[5][i] = f[6][i] = 0;
    f[1][i] = f[2][i] = f[4][i] = f[7][i] = 1;
  }
*/

/*
  //beta = 2, p = 32, testP_num = 16
  //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
  for (size_t i = 0; i < 16; i++) {
    for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
      f[0][j] = 15 - i;
    }
  }

  for (size_t i = 0; i < 16; i++) {//+i
    for (size_t ii = 0; ii < N; ii++) {
      f[i][ii] = func3(f[0][ii], i, p);
    }
  }
*/

/*
  //beta = 3, p = 32, testP_num = 256
  //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
  for (size_t i = 0; i < 16; i++) {
    for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
      f[0][j] = 15 - i;
    }
  }

  for (size_t i = 0; i < 16; i++) {//+i
    for (size_t j = 0; j < 16; j++) {//+j
      for (size_t ii = 0; ii < N; ii++) {
        f[16*i+j][ii] = func2(f[0][ii], i, j, p);
      }
    }
  }
*/


  //beta = 4, p = 32, testP_num = 4096
  //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
  for (size_t i = 0; i < 16; i++) {
    for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
      f[0][j] = 15 - i;
    }
  }

  for (size_t i = 0; i < 16; i++) {//+i
    for (size_t j = 0; j < 16; j++) {//+j
      for (size_t z = 0; z < 16; z++) {//+z
        for (size_t ii = 0; ii < N; ii++) {
          f[256*i+16*j+z][ii] = func(f[0][ii], i, j, z, p);
        }
      }
    }
  }


  TorusPolynomial *testP = polynomial_new_array_of_torus_polynomials(N, testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    for (size_t j = 0; j < N; j++) {
      testP[i]->coeffs[j] = int2torus(-f[i][j], pre);
    }
  }
  //printf("complete.\n");

  //printf("Preparing for key switch key ... ");
  TLWE_Key lwe_key = tlwe_alloc_key(N, 0);
  trlwe_extract_tlwe_key(lwe_key, rlwe_key);
  TRLWE_KS_Key ks_key = trlwe_new_full_packing_KS_key(rlwe_key, lwe_key, t, base_bit);
  free_tlwe_key(lwe_key);
  //printf("complete.\n");


  //printf("Preparing for auk ... ");
  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key, true, l_auk, B_auk);
  //printf("complete.\n");
  
  clock_t start, end;
  double ms_time;
  //printf("Tree-based External Product ...\n");
  start = clock();

  TRLWE result = TEP(c_rgsw, testP, ks_key, auk, rlwe_key, N, k, l, B, beta, pre, testP_num);

  end = clock();
  //printf("complete.\n");

  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);

  //TEP verify
  
  TorusPolynomial plain = polynomial_new_torus_polynomial(N);
  trlwe_phase(plain, result, rlwe_key);
  printf("result = %lu\n", torus2int(plain->coeffs[0], pre));
  free_polynomial(plain);


  //printf("Cleaning data ... ");

  free_polynomial(result);
  free_array_of_polynomials(testP, testP_num);
  free_trgsw_array(c_rgsw, beta);

  free_trlwe_key(rlwe_key);
  free_trlwe_ks_key(ks_key);
  free_trgsw_key(rgsw_key);

  for (size_t i = 0; i < N; i++) free_trlwe_ks_key(auk[i]);
  free(auk);

  //printf("complete.\n");

  return 0;
}



















