#include <mosfhet.h>
#include "function.h"
#include <time.h>
#include <sys/time.h>

bsk_list create_bsk_list(uint32_t lv, int *rows,
TRGSW_DFT *bsk[4][4], TRGSW_DFT *tau_bsk[4][4]) {
  bsk_list res = (bsk_list)malloc(sizeof(bsk_node));
  bsk_node *ptr = res, *qtr;
  ptr->k0 = bsk[rows[0]][0]; ptr->k1 = bsk[rows[0]][1];
  ptr->k2 = bsk[rows[0]][2]; ptr->k3 = bsk[rows[0]][3];
  ptr->tk0 = tau_bsk[rows[0]][0]; ptr->tk1 = tau_bsk[rows[0]][1];
  ptr->tk2 = tau_bsk[rows[0]][2]; ptr->tk3 = tau_bsk[rows[0]][3];
  ptr->next = NULL;
  for (size_t i = 1; i < lv; i++) {
    qtr = (bsk_list)malloc(sizeof(bsk_node));
    ptr->next = qtr;
    ptr = ptr->next;
    ptr->next = NULL;
    qtr = NULL;
    ptr->k0 = bsk[rows[i]][0]; ptr->k1 = bsk[rows[i]][1];
    ptr->k2 = bsk[rows[i]][2]; ptr->k3 = bsk[rows[i]][3];
    ptr->tk0 = tau_bsk[rows[i]][0]; ptr->tk1 = tau_bsk[rows[i]][1];
    ptr->tk2 = tau_bsk[rows[i]][2]; ptr->tk3 = tau_bsk[rows[i]][3];

  }
  return res;
}

void delete_bsk_list(bsk_list list) {
  assert(list != NULL);
  bsk_node *ptr = list, *qtr;
  while (ptr->next != NULL) {
    qtr = ptr->next;
    ptr->next = qtr->next;
    free(qtr);
  }
  free(ptr);
}

bsk_head_list create_bsk_head_list(uint32_t diffnum, uint32_t *all_lv, int **all_rows,
TRGSW_DFT *bsk[4][4], TRGSW_DFT *tau_bsk[4][4]) {
  bsk_head_list res = (bsk_head_list)malloc(sizeof(bsk_head_node));
  bsk_head_node *ptr = res, *qtr;
  ptr->value = create_bsk_list(all_lv[0], all_rows[0], bsk, tau_bsk);
  ptr->next = NULL;
  for (size_t i = 1; i < diffnum; i++) {
    qtr = (bsk_head_list)malloc(sizeof(bsk_head_node));
    ptr->next = qtr;
    ptr = ptr-> next;
    ptr->next = NULL;
    qtr = NULL;
    ptr->value = create_bsk_list(all_lv[i], all_rows[i], bsk, tau_bsk);
  }
  return res;
}

void delete_bsk_head_list(bsk_head_list list) {
  assert(list != NULL);
  bsk_head_node *ptr = list, *qtr;
  while (ptr->next != NULL) {
    qtr = ptr->next;
    ptr->next = qtr->next;
    delete_bsk_list(qtr->value);
    free(qtr);
  }
  delete_bsk_list(ptr->value);
  free(ptr);
}

void tau_trgsw_monomial_sample(TRGSW out, int64_t m, int e, TRGSW_Key key) {
  const int l = key->l, Bg_bit = key->Bg_bit, N = key->trlwe_key->s[0]->N;
  assert(key->trlwe_key->k == 1);
  if (e&N) {
    m *= -1;
  }
  e &= (N - 1);
  for (size_t i = l; i < 2 * l; i++) {
    trlwe_sample(out->samples[i], NULL, key->trlwe_key);
  }
  TorusPolynomial tau_s = polynomial_new_torus_polynomial(N);
  TorusPolynomial tau_smB = polynomial_new_torus_polynomial(N);
  TorusPolynomial _tau_smB = polynomial_new_torus_polynomial(N);
  TorusPolynomial zero = polynomial_new_torus_polynomial(N);
  polynomial_permute(tau_s, *(key->trlwe_key->s), -1);
  for (size_t i = 0; i < l; i++) {
    const Torus h = 1UL << (sizeof(Torus) * 8 - (i + 1) * Bg_bit);
    for (size_t j = 0; j < N; j++) {
      tau_smB->coeffs[j] = tau_s->coeffs[j] * m * h;
    }
    polynomial_sub_torus_polynomials(_tau_smB, zero, tau_smB);
    trlwe_sample(out->samples[i], _tau_smB, key->trlwe_key);
    out->samples[l + i]->b->coeffs[e] += m * h;
  }
  free_polynomial(tau_s);
  free_polynomial(tau_smB);
  free_polynomial(_tau_smB);
  free_polynomial(zero);
}

TRGSW tau_trgsw_new_monomial_sample(int64_t m, int e, TRGSW_Key key) {
  const int l = key->l, k = key->trlwe_key->k, Bg_bit = key->Bg_bit, N = key->trlwe_key->s[0]->N;
  TRGSW res = trgsw_alloc_new_sample(l, Bg_bit, k, N);
  tau_trgsw_monomial_sample(res, m, e, key);
  return res;
}

TRGSW tau_trgsw_new_sample(Torus m, TRGSW_Key key) {
  return tau_trgsw_new_monomial_sample(m, 0, key);
}

TRLWE trlwe_new_sample_(TorusPolynomial m, TRLWE_Key key) {
  const int N = key->s[0]->N;
  Torus max = sizeof(Torus) == sizeof(uint64_t) ? UINT64_MAX : UINT32_MAX;
  TRLWE res = trlwe_alloc_new_sample(key->k, N);
  srandom(time(NULL));
  for (size_t i = 0; i < key->k; i++) {
    for (size_t j = 0; j < N; j++) {
      res->a[i]->coeffs[j] = random() % max;
    }
  }
  generate_torus_normal_random_array(res->b->coeffs, key->sigma, N);
  for (size_t i = 0; i < key->k; i++) {
    polynomial_mul_addto_torus(res->b, res->a[i], key->s[i]);
  }
  if (m != NULL) {
    for (size_t i = 0; i < m->N; i++) {
      res->b->coeffs[i] += m->coeffs[i];
    }
  }
  return res;
}


void gen_sparse_binary_array(uint64_t *out, uint64_t size, uint64_t h) {
  uint32_t max = floor(size / h) - 1;
  memset(out, 0, sizeof(uint64_t) * size);
  srandom(time(NULL));

  uint32_t index = 0, dis;
  for (size_t i = 0; i < h; i++) {
    dis = (random() % max) + 1;
    index += dis;
    out[index] = 1;
  }
}

TLWE_Key tlwe_new_binary_key_with_hw(int N, int h, double sigma) {
  TLWE_Key res = tlwe_alloc_key(N, sigma);
  gen_sparse_binary_array(res->s, N, h);
  return res;
}

TRLWE_Key trlwe_new_binary_key_with_hw(int N, int k, int h, double sigma) {
  TRLWE_Key res = trlwe_alloc_key(N, k, sigma);
  for (size_t i = 0; i < k; i++) {
    gen_sparse_binary_array(res->s[i]->coeffs, N, h);
    polynomial_torus_to_DFT(res->s_dft[i], res->s[i]);
  }
  return res;
}

TRLWE_Key trlwe_new_binary_key_with_hw_balance(int N, int k, int h, int bound, double sigma) {
  uint32_t block_size = bound;
  srandom(time(NULL));
  int index, maxindex = 0;
  TRLWE_Key res = trlwe_alloc_key(N, k, sigma);
  for (size_t i = 0; i < k; i++) {
    for (size_t j = 0; j < h; j++) {
      index = random() % block_size;
      maxindex += index;
      res->s[i]->coeffs[maxindex] = 1;
    }
    polynomial_torus_to_DFT(res->s_dft[i], res->s[i]);
  }
  return res;
}


TRLWE fullCase(TorusPolynomial m, TorusPolynomial testP, TRLWE rlwe, TRLWE_Key rlwe_key,
               bsk_head_list all_list,
               uint32_t N, uint32_t n, uint32_t k, uint32_t h, uint32_t l, uint32_t B, int pre,
               uint32_t diffnum, uint32_t *all_lv, int t, int base_bit, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk)
{
  //struct timeval start, end;
  //double time_pass;

  //gettimeofday(&start, NULL);
  TRLWE *c = trlwe_alloc_new_sample_array(n, k, N);
  TRLWE_DFT *c_DFT = trlwe_alloc_new_DFT_sample_array(n, k, N);
  TRLWE **c_dec = (TRLWE **)malloc(n * sizeof(TRLWE *));
  for (size_t i = 0; i < n; i++)
    c_dec[i] = trlwe_alloc_new_sample_array(l, k, N);
  TRLWE_DFT **c_dec_DFT = (TRLWE_DFT **)malloc(n * sizeof(TRLWE_DFT *));
  for (size_t i = 0; i < n; i++)
    c_dec_DFT[i] = trlwe_alloc_new_DFT_sample_array(l, k, N);
  //gettimeofday(&end, NULL);
  //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
  //printf("malloc time: %f ms\n", time_pass * 1000.f);

  //gettimeofday(&start, NULL);
  TorusPolynomial testPxbi = polynomial_new_torus_polynomial(N);
  for (size_t i = 0; i < n; i++)
  {
    uint64_t bi = torus2int(rlwe->b->coeffs[i], (int)log2(2 * N)) + N / (1 << pre);
    torus_polynomial_mul_by_xai(testPxbi, testP, bi);
    trlwe_noiseless_trivial_sample(c[i], testPxbi);
  }
  free_polynomial(testPxbi);
  TRLWE temp = trlwe_alloc_new_sample(k, N);
  //gettimeofday(&end, NULL);
  //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
  //printf("ciphertext time: %f ms\n", time_pass * 1000.f);
  bsk_head_node *ptr = all_list;
  for (size_t i = 0; i < diffnum - 1; i++)
  {
    //gettimeofday(&start, NULL);
    IMPmul_negative(c, c_dec, c_DFT, c_dec_DFT, N, n, k, l, B, all_lv[i], ptr->value);
    //IMPmul_negative_my(c, c_dec, c_DFT, c_dec_DFT, N, n, k, l, B, all_lv[i], ptr->value);
    ptr = ptr->next;

    for (size_t j = 0; j < n; j++)
    {
      int a = -torus2int(rlwe->a[0]->coeffs[j], (int)log2(2 * N));
      if (a != 0)
      {
        trlwe_mul_by_xai(temp, c[j], a);
        trlwe_copy(c[j], temp);
      }
    }
    //gettimeofday(&end, NULL);
    //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
    //printf("i:%ld IMPmul_negative time: %f ms\n", i, time_pass * 1000.f);
  }

  //gettimeofday(&start, NULL);
  IMPmul_positive(c, c_dec, c_DFT, c_dec_DFT, N, n, k, l, B, all_lv[diffnum - 1], ptr->value);
  //IMPmul_positive_my(c, c_dec, c_DFT, c_dec_DFT, N, n, k, l, B, all_lv[diffnum - 1], ptr->value);
  //gettimeofday(&end, NULL);
  //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
  //printf("IMPmul_positive time: %f ms\n", time_pass * 1000.f);

/*
  printf("\nVerify:\n");
int err = 0;
for (size_t i = 0; i < n; i++) {
  TorusPolynomial plain = polynomial_new_torus_polynomial(N);
  trlwe_phase(plain, c[i], rlwe_key);
if (torus2int(m->coeffs[i],pre) != torus2int(plain->coeffs[0], pre))err++;
  printf("%lu, ", torus2int(plain->coeffs[0], pre));
  free_polynomial(plain);
}
*/
//printf("err=%d\n",err);


  //gettimeofday(&start, NULL);
  TRLWE out = trlwe_alloc_new_sample(k, N);
  trlwe_repacking(out, c, ks_key, auk, N, k, n);
  //gettimeofday(&end, NULL);
  //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
  //printf("pack time: %f ms\n", time_pass * 1000.f);

  //gettimeofday(&start, NULL);
  free_trlwe(temp);
  // free_tlwe_array(c_extract, n);
  free_trlwe_array(c, n);
  free_trlwe_array(c_DFT, n);
  for (int i = 0; i < n; i++)
  {
    free_trlwe_array(c_dec[i], l);
    free_trlwe_array(c_dec_DFT[i], l);
  }
  free(c_dec);
  free(c_dec_DFT);
  //gettimeofday(&end, NULL);
  //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
  //printf("clear time: %f ms\n", time_pass * 1000.f);
  return out;
}

void homo_trace(TRLWE out, TRLWE in, uint32_t n, TRLWE_KS_Key *auk) {
  uint32_t N = in->b->N, k = in->k;
  assert(k == 1);
  TRLWE temp = trlwe_alloc_new_sample(k, N);
  trlwe_copy(out, in);
  for (size_t i = log2(n) + 1; i <= log2(N); i++) {
    //mod switch
    for (size_t z = 0; z < N; z++) {
      out->a[0]->coeffs[z] /= 2;
    }
    for (size_t z = 0; z < N; z++) {
      out->b->coeffs[z] /= 2;
    }
    //homo auto
    uint32_t gen = (1 << i) + 1;
    trlwe_eval_automorphism(temp, out, gen, auk[1 << (i-1)]);
    trlwe_addto(temp, out);
    trlwe_copy(out, temp);
  }
  free_trlwe(temp);
}

TRGSW *batch_circuit_bootstrap(TRLWE rlwe,
TRLWE_KS_Key *auk, TRLWE_KS_Key rvk,
uint32_t N, uint32_t n, uint32_t k, uint32_t h, uint32_t l_bsk, uint32_t B_bsk, int pre,
uint32_t diffnum, uint32_t *all_lv, bsk_head_list all_list,
uint32_t l_auk, uint32_t B_auk, uint32_t l_rvk, uint32_t B_rvk,
uint32_t l_, uint32_t B_) {

  assert(k == 1);

  TRLWE *c = (TRLWE *)malloc(n * sizeof(TRLWE));
  TRLWE_DFT* c_DFT = trlwe_alloc_new_DFT_sample_array(n, k, N);
  TRLWE **c_dec = (TRLWE **)malloc(n * sizeof(TRLWE*));
  for (size_t i = 0; i < n; i++) c_dec[i] = trlwe_alloc_new_sample_array(l_bsk, k, N);
  TRLWE_DFT **c_dec_DFT = (TRLWE_DFT **)malloc(n * sizeof(TRLWE_DFT *));
  for (size_t i = 0; i < n; i++) c_dec_DFT[i] = trlwe_alloc_new_DFT_sample_array(l_bsk, k, N);
  TRLWE rlwetemp = trlwe_alloc_new_sample(k, N);

  //modswitch
  for (size_t i = 0; i < N; i++) {
    rlwetemp->a[0]->coeffs[i] = l_ * torus2int(rlwe->a[0]->coeffs[i], log2(2*N/l_));
    rlwetemp->b->coeffs[i] = l_ * torus2int(rlwe->b->coeffs[i], log2(2*N/l_));
  }
  
  //generate ciphertexts
  for (size_t i = 0; i < n; i++) {
    TorusPolynomial Bxbi = polynomial_new_torus_polynomial(N);
    int bi = rlwetemp->b->coeffs[i];
    for (uint32_t j = 0; j < l_; j++) {
      Torus coe = 1UL << (sizeof(Torus) * 8 - (j + 1) * B_);
      int ind = (bi + j) % (2 * N);
      if (ind < N) {
        Bxbi->coeffs[ind] = coe;
      } else {
        Bxbi->coeffs[ind % N] = -coe;
      }
    }
    c[i] = trlwe_new_noiseless_trivial_sample(Bxbi, k, N);
    free_polynomial(Bxbi);
  }
  //batch bootstrap
  bsk_head_node *ptr = all_list;
  TRLWE temp = trlwe_alloc_new_sample(k, N);
  for (size_t i = 0; i < diffnum - 1; i++) {
    IMPmul_negative(c, c_dec, c_DFT, c_dec_DFT,
N, n, k, l_bsk, B_bsk, all_lv[i], ptr->value);
    ptr = ptr->next;
    for (size_t j = 0; j < n; j++) {
      int a = -rlwetemp->a[0]->coeffs[j];
      if (a != 0) {
        trlwe_mul_by_xai(temp, c[j], a);
        trlwe_copy(c[j], temp);
      }
    }
  }

  IMPmul_positive(c, c_dec, c_DFT, c_dec_DFT,
N, n, k, l_bsk, B_bsk, all_lv[diffnum - 1], ptr->value);
  free_trlwe(temp);


  //homotrace + vkeyswitch
  TRGSW *c_rgsw = trgsw_alloc_new_sample_array(n, l_, B_, k, N);
  TRLWE *temp2 = trlwe_alloc_new_sample_array(2*l_, k, N);
  for (size_t i = 0; i < n; i++) {
    for (size_t j = 0; j < 2*l_; j++) {
      if (j != 0) {
        trlwe_mul_by_xai(temp2[j], c[i], -j);
      } else {
        trlwe_copy(temp2[j], c[i]);
      }
    }
    for (size_t j = 0; j < l_; j++) {
      homo_trace(c_rgsw[i]->samples[j + l_], temp2[j], N / l_, auk);
      trlwe_vkeyswitch(c_rgsw[i]->samples[j], c_rgsw[i]->samples[j + l_], rvk);
    }
  }


  free_trlwe_array(temp2, l_);
  for (int i = 0; i < n; i++) {
    free_trlwe(c[i]);
    free_trlwe(c_DFT[i]);
    free_trlwe_array(c_dec[i], l_bsk);
    free_trlwe_array(c_dec_DFT[i], l_bsk);
  }
  return c_rgsw;
}


void trlwe_vkeyswitch(TRLWE out, TRLWE in, TRLWE_KS_Key ks_key) {
  const int N = out->b->N;
  assert(out->k == ks_key->s[0][0]->k);
  assert(out->b->N == ks_key->s[0][0]->b->N);
  assert(k == 1);
  
  TorusPolynomial dec_in_a = polynomial_new_torus_polynomial(N);
  DFT_Polynomial tmp = polynomial_new_DFT_polynomial(N);
  TRLWE_DFT acc = trlwe_alloc_new_DFT_sample(out->k, N);
  TRLWE as = trlwe_alloc_new_sample(out->k, N);

  for (size_t i = 0; i < out->k; i++){
    for (size_t j = 0; j < N; j++) acc->a[i]->coeffs[j] = 0.;
  }
  for (size_t j = 0; j < N; j++) acc->b->coeffs[j] = 0.;
  
  for (size_t i = 0; i < in->k; i++){
    for (size_t j = 0; j < ks_key->t; j++){
      polynomial_decompose_i(dec_in_a, in->a[i], ks_key->base_bit, ks_key->t, j);
      polynomial_torus_to_DFT(tmp, dec_in_a);
      trlwe_DFT_mul_addto_by_polynomial(acc, ks_key->s[i][j], tmp);   
    }
  }
  trlwe_from_DFT(as, acc);
  memset(out->b->coeffs, 0, sizeof(Torus) * out->b->N);
  memcpy(out->a[0]->coeffs, in->b->coeffs, sizeof(Torus) * out->b->N);
  trlwe_addto(out, as);
  
  free_trlwe(acc);
  free_trlwe(as);
  free_polynomial(tmp);
  free_polynomial(dec_in_a);
}


void trgsw_mul_trlwe_b_DFT(TRLWE_DFT out, TorusPolynomial in1, TRGSW_DFT in2) {
  assert(in2->samples[0]->k == 1);
  const int N = in1->N, l = in2->l;

  TorusPolynomial dec_trlwe = polynomial_new_torus_polynomial(N);
  DFT_Polynomial dec_trlwe_DFT = polynomial_new_DFT_polynomial(N);

  polynomial_decompose_i(dec_trlwe, in1, in2->Bg_bit, in2->l, 0);
  polynomial_torus_to_DFT(dec_trlwe_DFT, dec_trlwe);
  polynomial_mul_DFT(out->a[0], dec_trlwe_DFT, in2->samples[l]->a[0]);
  polynomial_mul_DFT(out->b, dec_trlwe_DFT, in2->samples[l]->b);

  for (size_t j = 1; j < l; j++) {
    polynomial_decompose_i(dec_trlwe, in1, in2->Bg_bit, in2->l, j);
    polynomial_torus_to_DFT(dec_trlwe_DFT, dec_trlwe);
    polynomial_mul_addto_DFT(out->a[0], dec_trlwe_DFT, in2->samples[j + l]->a[0]);
    polynomial_mul_addto_DFT(out->b, dec_trlwe_DFT, in2->samples[j + l]->b);
  }

  free_polynomial(dec_trlwe);
  free_polynomial(dec_trlwe_DFT);
}

uint32_t fast_pow(uint32_t a, uint32_t b) {
  uint32_t res = 1;
  uint32_t base = a;
  uint32_t power = b;
  while (power > 0) {
    if (power & 1) res *= base;
    base *= base;
    power >>= 1;
  }
  return res;
}

void trlwe_repacking(TRLWE c_pack, TRLWE *c_rlwe, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk,
uint32_t N, uint32_t k, uint32_t n) {

  assert(k == 1);
  assert(rlwe_num > 1);
  TRLWE rlwetemp = trlwe_alloc_new_sample(k, N);
  TRLWE rlwetemp2 = trlwe_alloc_new_sample(k, N);

  TRLWE *c_rlwetemp = trlwe_alloc_new_sample_array(n, k, N);
  for (size_t i = 0; i < n; i++) {
    trlwe_copy(c_rlwetemp[i], c_rlwe[i]);
  }

  for (size_t i = 1; i <= log2(n); i++) {
    for (size_t j = 0; j < n / (1 << i); j++) {
      trlwe_mul_by_xai(rlwetemp2, c_rlwetemp[j + (n / (1 << i))], N / (1 << i));
      trlwe_subto(c_rlwetemp[j], rlwetemp2);
      for (size_t z = 0; z < N; z++) {
        c_rlwetemp[j]->a[0]->coeffs[z] /= 2;
      }
      for (size_t z = 0; z < N; z++) {
        c_rlwetemp[j]->b->coeffs[z] /= 2;
      }
      trlwe_eval_automorphism(rlwetemp, c_rlwetemp[j], (1 << i) + 1, auk[1 << (i - 1)]);
      trlwe_addto(c_rlwetemp[j], rlwetemp);
      trlwe_addto(c_rlwetemp[j], rlwetemp2);
    }
  }
  if (n < N) homo_trace(c_pack, c_rlwetemp[0], n, auk);
  else trlwe_copy(c_pack, c_rlwetemp[0]);
  free_trlwe_array(c_rlwetemp, n);
  free_trlwe(rlwetemp);
  free_trlwe(rlwetemp2); 
  return;
}


uint32_t trlwe_all_repacking(TRLWE *c_rlwe_pack, TRLWE *c_rlwe, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk,
uint32_t N, uint32_t k, int pre, uint32_t rlwe_num) {

  uint32_t p = 1 << pre, n = p >> 1, group_num = rlwe_num / n;
  assert(k == 1); assert(n <= N); assert(rlwe_num > 1);
  TRLWE rlwetemp = trlwe_alloc_new_sample(k, N);
  TRLWE rlwetemp2 = trlwe_alloc_new_sample(k, N);
  for (size_t g = 0; g < group_num; g++) {//c g*n (g+1)n-1

    TRLWE *c_rlwetemp = trlwe_alloc_new_sample_array(n, k, N);
    for (size_t i = 0; i < n; i++) {
      trlwe_copy(c_rlwetemp[i], c_rlwe[g * n + n - i - 1]);
    }

    for (size_t i = 1; i <= log2(n); i++) {
      for (size_t j = 0; j < n / (1 << i); j++) {
        trlwe_mul_by_xai(rlwetemp2, c_rlwetemp[j + (n / (1 << i))], N / (1 << i));
        trlwe_subto(c_rlwetemp[j], rlwetemp2);
        for (size_t z = 0; z < N; z++) {
          c_rlwetemp[j]->a[0]->coeffs[z] /= 2;
        }
        for (size_t z = 0; z < N; z++) {
          c_rlwetemp[j]->b->coeffs[z] /= 2;
        }
        trlwe_eval_automorphism(rlwetemp, c_rlwetemp[j], (1 << i) + 1, auk[1 << (i - 1)]);
        trlwe_addto(c_rlwetemp[j], rlwetemp);
        trlwe_addto(c_rlwetemp[j], rlwetemp2);
      }
    }
    if (n < N) homo_trace(c_rlwe_pack[g], c_rlwetemp[0], n, auk);
    else trlwe_copy(c_rlwe_pack[g], c_rlwetemp[0]);
    free_trlwe_array(c_rlwetemp, n);


  }//g
  free_trlwe(rlwetemp); free_trlwe(rlwetemp2); 
  return group_num;
}

TRLWE TEP(TRGSW *c_rgsw, TorusPolynomial *testP, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk, 
TRLWE_Key rlwe_key,
uint32_t N, uint32_t k, uint32_t l, uint32_t B, uint32_t beta, int pre, uint32_t testP_num) {

  assert(k == 1);
  uint32_t p = 1 << pre;

  TRLWE *c_rlwe = trlwe_alloc_new_sample_array(testP_num, k, N);
  TRLWE *c_rlwe_pack = trlwe_alloc_new_sample_array(testP_num, k, N);
  TRLWE_DFT rlwetemp_DFT = trlwe_alloc_new_DFT_sample(k, N);
  TRGSW_DFT rgswtemp_DFT = trgsw_alloc_new_DFT_sample(l, B, k, N);
  uint32_t rlwe_num = testP_num;

  //X^(b + N / p)
  TRGSW rgswtemp = trgsw_alloc_new_sample(l, B, k, N);
  for (size_t i = 0; i < beta; i++) {
    trgsw_mul_by_xai(rgswtemp, c_rgsw[i], N / p);
    trgsw_copy(c_rgsw[i], rgswtemp);
  }
  free_trgsw(rgswtemp);


  clock_t start, end;
  double ms_time;
  start = clock();

  //first half external product, r = 0
  trgsw_to_DFT(rgswtemp_DFT, c_rgsw[0]);
  for (size_t i = 0; i < rlwe_num; i++) {
    trgsw_mul_trlwe_b_DFT(rlwetemp_DFT, testP[i], rgswtemp_DFT);
    trlwe_from_DFT(c_rlwe[i], rlwetemp_DFT);
  }

  end = clock();
  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("first time: %f ms\n", ms_time);

  //first repacking
  rlwe_num = trlwe_all_repacking(c_rlwe_pack, c_rlwe, ks_key, auk, N, k, pre, rlwe_num);

  //mult polynomial
  TorusPolynomial poly = polynomial_new_torus_polynomial(N);
  DFT_Polynomial poly_DFT = polynomial_new_DFT_polynomial(N);
  for (size_t i = N / (p >> 1); i < N; i++) {
    poly->coeffs[i] = 0;
  }
  for (size_t i = 0; i < N / (p >> 1); i++) {
    poly->coeffs[i] = -1;
  }
  polynomial_torus_to_DFT(poly_DFT, poly);
  TRLWE_DFT trlwe_DFT = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT trlwe2_DFT = trlwe_alloc_new_DFT_sample(k, N);
  for (size_t i = 0; i < rlwe_num; i++) {
    trlwe_to_DFT(trlwe_DFT, c_rlwe_pack[i]);
    trlwe_DFT_mul_by_polynomial(trlwe2_DFT, trlwe_DFT, poly_DFT);
    trlwe_from_DFT(c_rlwe_pack[i], trlwe2_DFT);
  }

  //2th to (beta-1)th external product + sparse packing, r = 1, ..., beta - 2
  for (size_t r = 1; r < beta - 1; r++) {
    //external product
    trgsw_to_DFT(rgswtemp_DFT, c_rgsw[r]);
    for (size_t i = 0; i < rlwe_num; i++) {
      trgsw_mul_trlwe_DFT(rlwetemp_DFT, c_rlwe_pack[i], rgswtemp_DFT);
      trlwe_from_DFT(c_rlwe[i], rlwetemp_DFT);
    }
    //repacking
    rlwe_num = trlwe_all_repacking(c_rlwe_pack, c_rlwe, ks_key, auk, N, k, pre, rlwe_num);

    //mul poly
    for (size_t i = N / (p >> 1); i < N; i++) {
      poly->coeffs[i] = 0;
    }
    for (size_t i = 0; i < N / (p >> 1); i++) {
      poly->coeffs[i] = -1;
    }
    polynomial_torus_to_DFT(poly_DFT, poly);
    TRLWE_DFT trlwe_DFT = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT trlwe2_DFT = trlwe_alloc_new_DFT_sample(k, N);
    for (size_t i = 0; i < rlwe_num; i++) {
      trlwe_to_DFT(trlwe_DFT, c_rlwe_pack[i]);
      trlwe_DFT_mul_by_polynomial(trlwe2_DFT, trlwe_DFT, poly_DFT);
      trlwe_from_DFT(c_rlwe_pack[i], trlwe2_DFT);
    }
  }
  free_polynomial(poly);
  free_polynomial(poly_DFT);

  //last external product, r = beta - 1
  trgsw_to_DFT(rgswtemp_DFT, c_rgsw[beta - 1]);
  for (size_t i = 0; i < rlwe_num; i++) {
    trgsw_mul_trlwe_DFT(rlwetemp_DFT, c_rlwe_pack[0], rgswtemp_DFT);
    trlwe_from_DFT(c_rlwe[i], rlwetemp_DFT);
  }

  TRLWE res = trlwe_alloc_new_sample(k, N);
  trlwe_copy(res, c_rlwe[0]);

  free_trlwe_array(c_rlwe, testP_num);
  free_trlwe_array(c_rlwe_pack, testP_num);
  free_trlwe(rlwetemp_DFT);
  free_trgsw(rgswtemp_DFT);

  return res;
}


void decompose(TRLWE** c_dec, TRLWE* c, uint32_t n, uint32_t N, uint32_t B, uint32_t l, uint32_t k) {
  assert(k == 1);
  const int bit_size = sizeof(Torus) * 8;
  const uint64_t half_Bg = (1UL << (B - 1));
  const uint64_t h_mask = (1UL << B) - 1;
  uint64_t offset = 0;
  for (size_t i = 0; i < l; i++) {
    offset += (1UL << (bit_size - i * B - 1));
  }
  for (size_t h = 0; h < n; h++) {
    for (size_t i = 0; i < l; i++) {
      const uint64_t h_bit = bit_size - (i + 1) * B;
      for (size_t j = 0; j < N; j++) {
        const uint64_t coeff_off = c[h]->a[0]->coeffs[j] + offset;
        c_dec[h][i]->a[0]->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
      }
    }
    for (size_t i = 0; i < l; i++) {
      const uint64_t h_bit = bit_size - (i + 1) * B;
      for (size_t j = 0; j < N; j++) {
        const uint64_t coeff_off = c[h]->b->coeffs[j] + offset;
        c_dec[h][i]->b->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
      }
    }
  }
}
void decompose1(TRLWE **c_dec, TRLWE *c, uint32_t n,
               uint32_t N, uint32_t B, uint32_t l, uint32_t k)
{
    int bit_size = sizeof(Torus) * 8;
    uint64_t half_Bg = (1UL << (B - 1));
    uint64_t h_mask = (1UL << B) - 1;
    uint64_t offset = 0;
    uint64_t h_bit;
    uint64_t coeff_off;

    for (size_t i = 0; i < l; i++)
    {
        offset += (1UL << (bit_size - i * B - 1));
    }
    for (size_t h = 0; h < n; h++)
    {
        for (size_t i = 0; i < l; i++)
        {
            h_bit = bit_size - (i + 1) * B;
            for (size_t j = 0; j < N; j++)
            {
                coeff_off = c[h]->a[0]->coeffs[j] + offset;
                c_dec[h][i]->a[0]->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
                coeff_off = c[h]->b->coeffs[j] + offset;
                c_dec[h][i]->b->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
            }
        }
    }

    return;
}

void emp_decompose1(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B)
{
    uint32_t i, j;
    uint64_t bit_size;
    uint64_t half_Bg;
    uint64_t h_mask;
    uint64_t offset;
    uint64_t h_bit;
    uint64_t coeff_off;

    half_Bg = 1UL << (B - 1);
    h_mask = (1UL << B) - 1;
    bit_size = sizeof(Torus) * 8;
    offset = 1UL << (bit_size - 1);
    h_bit = bit_size - B;

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < N; j++)
        {
            coeff_off = c[i]->a[0]->coeffs[j] + offset;
            c_dec[i][0]->a[0]->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
            coeff_off = c[i]->b->coeffs[j] + offset;
            c_dec[i][0]->b->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
        }
    }

    return;
}

void emp_decompose2(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B)
{
    uint32_t i, j;
    uint32_t h_bit;

    h_bit = sizeof(Torus) * 8 - B;

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < N; j++)
        {
            c_dec[i][0]->a[0]->coeffs[j] = c[i]->a[0]->coeffs[j] >> h_bit;
            c_dec[i][0]->b->coeffs[j] = c[i]->b->coeffs[j] >> h_bit;
        }
    }

    return;
}

void emp_decompose3(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B)
{
    uint32_t i, j;
    uint32_t shift_bit;

    shift_bit = sizeof(Torus) * 8 - B;

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < N; j++)
            c_dec[i][0]->a[0]->coeffs[j] = c[i]->a[0]->coeffs[j] >> shift_bit;

        for (j = 0; j < N / 2; j++)
            c_dec[i][0]->b->coeffs[j] = c[i]->b->coeffs[j] >> shift_bit;
    }

    return;
}

void emp_decompose(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B)
{
    uint32_t i, j;
    uint32_t shift_bit;
    __m512i *in_a;
    __m512i *in_b;
    __m512i *out_a;
    __m512i *out_b;

    shift_bit = sizeof(Torus) * 8 - B;

    for (i = 0; i < n; i++)
    {
        in_a = (__m512i *)c[i]->a[0]->coeffs;
        in_b = (__m512i *)c[i]->b->coeffs;
        out_a = (__m512i *)c_dec[i][0]->a[0]->coeffs;
        out_b = (__m512i *)c_dec[i][0]->b->coeffs;

        for (j = 0; j < N / 8; j++)
            out_a[j] = _mm512_srli_epi64(in_a[j], shift_bit);
        for (j = 0; j < N / 16; j++)
            out_b[j] = _mm512_srli_epi64(in_b[j], shift_bit);
    }

    return;
}

void emp_decompose4(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B)
{
    uint32_t i, j;
    uint32_t shift_bit;
    __m512i *in_a;
    __m512i *in_b;
    __m512i *out_a;
    __m512i *out_b;

    shift_bit = sizeof(Torus) * 8 - B;

    for (i = 0; i < n; i++)
    {
        in_a = (__m512i *)c[i]->a[0]->coeffs;
        in_b = (__m512i *)c[i]->b->coeffs;
        out_a = (__m512i *)c_dec[i][0]->a[0]->coeffs;
        out_b = (__m512i *)c_dec[i][0]->b->coeffs;

        for (j = 0; j < N / 8; j++)
        {
            out_a[j] = _mm512_srli_epi64(in_a[j], shift_bit);
            out_b[j] = _mm512_srli_epi64(in_b[j], shift_bit);
        }
    }

    return;
}

void polynomial_permute_DFT_inverse(DFT_Polynomial out, DFT_Polynomial in)
{
    uint32_t N = in->N;
    for (size_t i = 0; i < N / 2; i++)
    {
        out->coeffs[i] = in->coeffs[i];
    }
    for (size_t i = N / 2; i < N; i++)
    {
        out->coeffs[i] = -(in->coeffs[i]);
    }
}

void trgsw_DFT_mul_trlwe_dec_DFT(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2,
                                  uint32_t n, uint32_t N, uint32_t l, uint32_t k)
{
    assert(k == 1);
    polynomial_mul_DFT(out->a[0], in1[0]->a[0], in2->samples[0]->a[0]);
    polynomial_mul_DFT(out->b, in1[0]->a[0], in2->samples[0]->b);
    for (size_t j = 1; j < l; j++)
    {
        polynomial_mul_addto_DFT(out->a[0], in1[j]->a[0], in2->samples[j]->a[0]);
        polynomial_mul_addto_DFT(out->b, in1[j]->a[0], in2->samples[j]->b);
    }
    for (size_t j = 0; j < l; j++)
    {
        polynomial_mul_addto_DFT(out->a[0], in1[j]->b, in2->samples[j + l]->a[0]);
        polynomial_mul_addto_DFT(out->b, in1[j]->b, in2->samples[j + l]->b);
    }
}

void trgsw_DFT_mul_trlwe_dec_DFT1(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2,
                                 uint32_t n, uint32_t N, uint32_t l, uint32_t k)
{
    int i, j;
    __m512d *in1_a;
    __m512d *in1_b;
    __m512d *in2_a;
    __m512d *in2_b;
    __m512d *in2_l_a;
    __m512d *in2_l_b;
    __m512d *out_a;
    __m512d *out_b;

    memset(out->a[0]->coeffs, 0, N * sizeof(double));
    memset(out->b->coeffs, 0, N * sizeof(double));

    out_a = (__m512d *)out->a[0]->coeffs;
    out_b = (__m512d *)out->b->coeffs;
    for (i = 0; i < l; i++)
    {
        in1_a = (__m512d *)in1[i]->a[0]->coeffs;
        in1_b = (__m512d *)in1[i]->b->coeffs;
        in2_a = (__m512d *)in2->samples[i]->a[0]->coeffs;
        in2_b = (__m512d *)in2->samples[i]->b->coeffs;
        in2_l_a = (__m512d *)in2->samples[i + l]->a[0]->coeffs;
        in2_l_b = (__m512d *)in2->samples[i + l]->b->coeffs;

        for (j = 0; j < N / 16; j++)
        {
            out_a[j] = _mm512_fmsub_pd(in1_a[j + N / 16], in2_a[j + N / 16], out_a[j]);
            out_a[j + N / 16] = _mm512_fmadd_pd(in1_a[j], in2_a[j + N / 16], out_a[j + N / 16]);
            out_b[j] = _mm512_fmsub_pd(in1_a[j + N / 16], in2_b[j + N / 16], out_b[j]);

            out_a[j] = _mm512_fmsub_pd(in1_a[j], in2_a[j], out_a[j]);
            out_a[j + N / 16] = _mm512_fmadd_pd(in1_a[j + N / 16], in2_a[j], out_a[j + N / 16]);
            out_b[j] = _mm512_fmsub_pd(in1_a[j], in2_b[j], out_b[j]);

            out_a[j] = _mm512_fmsub_pd(in1_b[j + N / 16], in2_l_a[j + N / 16], out_a[j]);
            out_a[j + N / 16] = _mm512_fmadd_pd(in1_b[j], in2_l_a[j + N / 16], out_a[j + N / 16]);
            out_b[j] = _mm512_fmsub_pd(in1_b[j + N / 16], in2_l_b[j + N / 16], out_b[j]);

            out_a[j] = _mm512_fmsub_pd(in1_b[j], in2_l_a[j], out_a[j]);
            out_a[j + N / 16] = _mm512_fmadd_pd(in1_b[j + N / 16], in2_l_a[j], out_a[j + N / 16]);
            out_b[j] = _mm512_fmsub_pd(in1_b[j], in2_l_b[j], out_b[j]);
        }
    }
}

void tau_trgsw_DFT_mul_trlwe_dec_DFT(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2,
                                      uint32_t n, uint32_t N, uint32_t l, uint32_t k)
{
    assert(k == 1);
    DFT_Polynomial poly = polynomial_new_DFT_polynomial(N);

    polynomial_permute_DFT_inverse(poly, in1[0]->a[0]);
    polynomial_mul_DFT(out->a[0], poly, in2->samples[0]->a[0]);
    polynomial_mul_DFT(out->b, poly, in2->samples[0]->b);

    for (size_t j = 1; j < l; j++)
    {

        polynomial_permute_DFT_inverse(poly, in1[j]->a[0]);
        polynomial_mul_addto_DFT(out->a[0], poly, in2->samples[j]->a[0]);
        polynomial_mul_addto_DFT(out->b, poly, in2->samples[j]->b);
    }
    for (size_t j = 0; j < l; j++)
    {

        polynomial_permute_DFT_inverse(poly, in1[j]->b);
        polynomial_mul_addto_DFT(out->a[0], poly, in2->samples[j + l]->a[0]);
        polynomial_mul_addto_DFT(out->b, poly, in2->samples[j + l]->b);
    }
    free_polynomial(poly);
}

void tau_trgsw_DFT_mul_trlwe_dec_DFT1(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2,
                                     uint32_t n, uint32_t N, uint32_t l, uint32_t k)
{
    int i, j;
    __m512d *in1_a;
    __m512d *in1_b;
    __m512d *in2_a;
    __m512d *in2_b;
    __m512d *in2_l_a;
    __m512d *in2_l_b;
    __m512d *out_a;
    __m512d *out_b;

    memset(out->a[0]->coeffs, 0, N * sizeof(double));
    memset(out->b->coeffs, 0, N * sizeof(double));

    out_a = (__m512d *)out->a[0]->coeffs;
    out_b = (__m512d *)out->b->coeffs;
    for (i = 0; i < l; i++)
    {
        in1_a = (__m512d *)in1[i]->a[0]->coeffs;
        in1_b = (__m512d *)in1[i]->b->coeffs;
        in2_a = (__m512d *)in2->samples[i]->a[0]->coeffs;
        in2_b = (__m512d *)in2->samples[i]->b->coeffs;
        in2_l_a = (__m512d *)in2->samples[i + l]->a[0]->coeffs;
        in2_l_b = (__m512d *)in2->samples[i + l]->b->coeffs;

        for (j = 0; j < N / 16; j++)
        {
            out_a[j] = _mm512_fmadd_pd(in1_a[j], in2_a[j], out_a[j]);
            out_a[j + N / 16] = _mm512_fmsub_pd(in1_a[j + N / 16], in2_a[j], out_a[j + N / 16]);
            out_b[j] = _mm512_fmadd_pd(in1_a[j], in2_b[j], out_b[j]);

            out_a[j] = _mm512_fmadd_pd(in1_a[j + N / 16], in2_a[j + N / 16], out_a[j]);
            out_a[j + N / 16] = _mm512_fmsub_pd(in1_a[j], in2_a[j + N / 16], out_a[j + N / 16]);
            out_b[j] = _mm512_fmadd_pd(in1_a[j + N / 16], in2_b[j + N / 16], out_b[j]);

            out_a[j] = _mm512_fmadd_pd(in1_b[j], in2_l_a[j], out_a[j]);
            out_a[j + N / 16] = _mm512_fmsub_pd(in1_b[j + N / 16], in2_l_a[j], out_a[j + N / 16]);
            out_b[j] = _mm512_fmadd_pd(in1_b[j], in2_l_b[j], out_b[j]);

            out_a[j] = _mm512_fmadd_pd(in1_b[j + N / 16], in2_l_a[j + N / 16], out_a[j]);
            out_a[j + N / 16] = _mm512_fmsub_pd(in1_b[j], in2_l_a[j + N / 16], out_a[j + N / 16]);
            out_b[j] = _mm512_fmadd_pd(in1_b[j + N / 16], in2_l_b[j + N / 16], out_b[j]);
        }
    }
}

void trlwe_dft_hadamard_sum(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t N)
{
    int i;
    __m512d *in1_a;
    __m512d *in1_b;
    __m512d *in2_a0;
    __m512d *in2_b0;
    __m512d *in2_a1;
    __m512d *in2_b1;
    __m512d *out_a;
    __m512d *out_b;

    memset(out->a[0]->coeffs, 0, N * sizeof(double));
    memset(out->b->coeffs, 0, N * sizeof(double));

    out_a = (__m512d *)out->a[0]->coeffs;
    out_b = (__m512d *)out->b->coeffs;
    in1_a = (__m512d *)in1[0]->a[0]->coeffs;
    in1_b = (__m512d *)in1[0]->b->coeffs;
    in2_a0 = (__m512d *)in2->samples[0]->a[0]->coeffs;
    in2_b0 = (__m512d *)in2->samples[0]->b->coeffs;
    in2_a1 = (__m512d *)in2->samples[1]->a[0]->coeffs;
    in2_b1 = (__m512d *)in2->samples[1]->b->coeffs;

    for (i = 0; i < N / 16; i++)
    {
        out_a[i] = _mm512_fmsub_pd(in1_a[i + N / 16], in2_a0[i + N / 16], out_a[i]);
        out_a[i + N / 16] = _mm512_fmadd_pd(in1_a[i], in2_a0[i + N / 16], out_a[i + N / 16]);
        out_b[i] = _mm512_fmadd_pd(in1_a[i + N / 16], in2_b0[i + N / 16], out_b[i]);

        out_a[i] = _mm512_fmsub_pd(in1_a[i], in2_a0[i], out_a[i]);
        out_a[i + N / 16] = _mm512_fmadd_pd(in1_a[i + N / 16], in2_a0[i], out_a[i + N / 16]);
        out_b[i] = _mm512_fmsub_pd(in1_a[i], in2_b0[i], out_b[i]);

        out_a[i] = _mm512_fmsub_pd(in1_b[i + N / 16], in2_a1[i + N / 16], out_a[i]);
        out_a[i + N / 16] = _mm512_fmadd_pd(in1_b[i], in2_a1[i + N / 16], out_a[i + N / 16]);
        out_b[i] = _mm512_fmsub_pd(in1_b[i + N / 16], in2_b1[i + N / 16], out_b[i]);

        out_a[i] = _mm512_fmsub_pd(in1_b[i], in2_a1[i], out_a[i]);
        out_a[i + N / 16] = _mm512_fmadd_pd(in1_b[i + N / 16], in2_a1[i], out_a[i + N / 16]);
        out_b[i] = _mm512_fmsub_pd(in1_b[i], in2_b1[i], out_b[i]);
    }

    return;
}

void trlwe_dft_hadamard_sum_automorphism(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t N)
{
    int i;
    __m512d *in1_a;
    __m512d *in1_b;
    __m512d *in2_a0;
    __m512d *in2_b0;
    __m512d *in2_a1;
    __m512d *in2_b1;
    __m512d *out_a;
    __m512d *out_b;

    memset(out->a[0]->coeffs, 0, N * sizeof(double));
    memset(out->b->coeffs, 0, N * sizeof(double));

    out_a = (__m512d *)out->a[0]->coeffs;
    out_b = (__m512d *)out->b->coeffs;
    in1_a = (__m512d *)in1[0]->a[0]->coeffs;
    in1_b = (__m512d *)in1[0]->b->coeffs;
    in2_a0 = (__m512d *)in2->samples[0]->a[0]->coeffs;
    in2_b0 = (__m512d *)in2->samples[0]->b->coeffs;
    in2_a1 = (__m512d *)in2->samples[1]->a[0]->coeffs;
    in2_b1 = (__m512d *)in2->samples[1]->b->coeffs;

    for (i = 0; i < N / 16; i++)
    {
        out_a[i] = _mm512_fmadd_pd(in1_a[i], in2_a0[i], out_a[i]);
        out_a[i + N / 16] = _mm512_fmsub_pd(in1_a[i + N / 16], in2_a0[i], out_a[i + N / 16]);
        out_b[i] = _mm512_fmadd_pd(in1_a[i], in2_b0[i], out_b[i]);

        out_a[i] = _mm512_fmadd_pd(in1_a[i + N / 16], in2_a0[i + N / 16], out_a[i]);
        out_a[i + N / 16] = _mm512_fmsub_pd(in1_a[i], in2_a0[i + N / 16], out_a[i + N / 16]);
        out_b[i] = _mm512_fmadd_pd(in1_a[i + N / 16], in2_b0[i + N / 16], out_b[i]);

        out_a[i] = _mm512_fmadd_pd(in1_b[i], in2_a1[i], out_a[i]);
        out_a[i + N / 16] = _mm512_fmsub_pd(in1_b[i + N / 16], in2_a1[i], out_a[i + N / 16]);
        out_b[i] = _mm512_fmadd_pd(in1_b[i], in2_b1[i], out_b[i]);

        out_a[i] = _mm512_fmadd_pd(in1_b[i + N / 16], in2_a1[i + N / 16], out_a[i]);
        out_a[i + N / 16] = _mm512_fmsub_pd(in1_b[i], in2_a1[i + N / 16], out_a[i + N / 16]);
        out_b[i] = _mm512_fmadd_pd(in1_b[i + N / 16], in2_b1[i + N / 16], out_b[i]);
    }

    return;
}

void trlwe_dft_sum1(TRLWE_DFT out, TRLWE_DFT in1, TRLWE_DFT in2, TRLWE_DFT in3, TRLWE_DFT in4, uint32_t N)
{
    // trlwe_DFT_add(out, in1, in2);
    // trlwe_DFT_add(out, out, in3);
    // trlwe_DFT_add(out, out, in4);

    // polynomial_add_DFT_polynomials(out->a[0], in1->a[0], in2->a[0]);
    // polynomial_add_DFT_polynomials(out->b, in1->b, in2->b);
    // polynomial_add_DFT_polynomials(out->a[0], out->a[0], in3->a[0]);
    // polynomial_add_DFT_polynomials(out->b, out->b, in3->b);
    // polynomial_add_DFT_polynomials(out->a[0], out->a[0], in4->a[0]);
    // polynomial_add_DFT_polynomials(out->b, out->b, in4->b);

    // for (size_t i = 0; i < in2->a[0]->N; i++)
    // {
    //     out->a[0]->coeffs[i] = in1->a[0]->coeffs[i] + in2->a[0]->coeffs[i];
    //     out->a[0]->coeffs[i] = out->a[0]->coeffs[i] + in3->a[0]->coeffs[i];
    //     out->a[0]->coeffs[i] = out->a[0]->coeffs[i] + in4->a[0]->coeffs[i];
    // }

    // for (size_t i = 0; i < in2->a[0]->N / 2; i++)
    // {
    //     out->b->coeffs[i] = in1->b->coeffs[i] + in2->b->coeffs[i];
    //     out->b->coeffs[i] = out->b->coeffs[i] + in3->b->coeffs[i];
    //     out->b->coeffs[i] = out->b->coeffs[i] + in4->b->coeffs[i];
    // }

    int i;
    __m512d *in1_a;
    __m512d *in1_b;
    __m512d *in2_a;
    __m512d *in2_b;
    __m512d *in3_a;
    __m512d *in3_b;
    __m512d *in4_a;
    __m512d *in4_b;
    __m512d *out_a;
    __m512d *out_b;
    __m512d tmp_a;
    __m512d tmp_b;

    in1_a = (__m512d *)in1->a[0]->coeffs;
    in1_b = (__m512d *)in1->b->coeffs;
    in2_a = (__m512d *)in2->a[0]->coeffs;
    in2_b = (__m512d *)in2->b->coeffs;
    in3_a = (__m512d *)in3->a[0]->coeffs;
    in3_b = (__m512d *)in3->b->coeffs;
    in4_a = (__m512d *)in4->a[0]->coeffs;
    in4_b = (__m512d *)in4->b->coeffs;
    out_a = (__m512d *)out->a[0]->coeffs;
    out_b = (__m512d *)out->b->coeffs;

    for (i = 0; i < N / 16; i++)
    {
        out_a[i] = _mm512_add_pd(in1_a[i], in2_a[i]);
        tmp_a = _mm512_add_pd(in3_a[i], in4_a[i]);
        out_a[i] = _mm512_add_pd(out_a[i], tmp_a);
        out_b[i] = _mm512_add_pd(in1_b[i], in2_b[i]);
        tmp_b = _mm512_add_pd(in3_b[i], in4_b[i]);
        out_b[i] = _mm512_add_pd(out_b[i], tmp_b);
    }

    for (i = N / 16; i < N / 8; i++)
    {
        out_a[i] = _mm512_add_pd(in1_a[i], in2_a[i]);
        tmp_a = _mm512_add_pd(in3_a[i], in4_a[i]);
        out_a[i] = _mm512_add_pd(out_a[i], tmp_a);
    }

    return;
}

void trlwe_dft_sum(TRLWE_DFT out, TRLWE_DFT in1, TRLWE_DFT in2, TRLWE_DFT in3, TRLWE_DFT in4, uint32_t N)
{
    int i;
    __m512d *in1_a;
    __m512d *in1_b;
    __m512d *in2_a;
    __m512d *in2_b;
    __m512d *in3_a;
    __m512d *in3_b;
    __m512d *in4_a;
    __m512d *in4_b;
    __m512d *out_a;
    __m512d *out_b;
    __m512d tmp_a;
    __m512d tmp_b;

    in1_a = (__m512d *)in1->a[0]->coeffs;
    in1_b = (__m512d *)in1->b->coeffs;
    in2_a = (__m512d *)in2->a[0]->coeffs;
    in2_b = (__m512d *)in2->b->coeffs;
    in3_a = (__m512d *)in3->a[0]->coeffs;
    in3_b = (__m512d *)in3->b->coeffs;
    in4_a = (__m512d *)in4->a[0]->coeffs;
    in4_b = (__m512d *)in4->b->coeffs;
    out_a = (__m512d *)out->a[0]->coeffs;
    out_b = (__m512d *)out->b->coeffs;

    for (i = 0; i < N / 16; i++)
    {
        out_a[i] = _mm512_add_pd(in1_a[i], in2_a[i]);
        out_b[i] = _mm512_add_pd(in1_b[i], in2_b[i]);
        tmp_a = _mm512_add_pd(in3_a[i], in4_a[i]);
        tmp_b = _mm512_add_pd(in3_b[i], in4_b[i]);
        out_a[i] = _mm512_add_pd(out_a[i], tmp_a);
        out_b[i] = _mm512_add_pd(out_b[i], tmp_b);
    }

    for (i = N / 16; i < N / 8; i++)
    {
        out_a[i] = _mm512_add_pd(in1_a[i], in2_a[i]);
        tmp_a = _mm512_add_pd(in3_a[i], in4_a[i]);
        out_a[i] = _mm512_add_pd(out_a[i], tmp_a);
    }

    return;
}

void IMPmul_positive_my(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT,
                        uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list)
{
    //struct timeval start, end;
    //double time_pass;

    //gettimeofday(&start, NULL);
    bsk_node *ptr = list;
    TRLWE_DFT cdft1 = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT cdft2 = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT cdft3 = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT cdft4 = trlwe_alloc_new_DFT_sample(k, N);
    //TRLWE_DFT cdft5 = trlwe_alloc_new_DFT_sample(k, N);
    //TRLWE_DFT cdft6 = trlwe_alloc_new_DFT_sample(k, N);
    //gettimeofday(&end, NULL);
    //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
    //printf("ciphertext time: %f ms\n", time_pass * 1000.f);

    //printf("B:%d\n", B);
    //printf("lv:%d   lv/2:%d\n", lv, lv / 2);
    for (size_t i = 0; i < lv / 2; i++)
    {
        uint64_t twoi = 1 << (2 * i);


        //gettimeofday(&start, NULL);
        //decompose(c_dec, c, n, N, B, l, k);
        emp_decompose(c_dec, c, n, N, B);
        //gettimeofday(&end, NULL);
        //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
        //printf("i:%ld emp_decompose time: %f ms\n", i, time_pass * 1000.f);

        //gettimeofday(&start, NULL);
        // for (size_t j = 0; j < n; j++)
        // {
        //     for (size_t z = 0; z < l; z++)
        //     {
        //         trlwe_to_DFT(c_dec_DFT[j][z], c_dec[j][z]);
        //     }
        // }
        for (size_t j = 0; j < n; j++)
        {
            trlwe_to_DFT(c_dec_DFT[j][0], c_dec[j][0]);
        }
        //gettimeofday(&end, NULL);
        //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
        //printf("i:%ld trlwe_to_DFT time: %f ms\n", i, time_pass * 1000.f);

        //gettimeofday(&start, NULL);
        for (size_t j = 0; j <= twoi - 1; j++)
        {
            trlwe_dft_hadamard_sum_automorphism(cdft1, c_dec_DFT[n + j - twoi], *(ptr->tk0), N);
            trlwe_dft_hadamard_sum_automorphism(cdft2, c_dec_DFT[n + j - twoi * 2], *(ptr->tk1), N);
            trlwe_dft_hadamard_sum_automorphism(cdft3, c_dec_DFT[n + j - twoi - twoi * 2], *(ptr->tk2), N);
            // trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->tk3), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);
        }
        //gettimeofday(&end, NULL);
        //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
        //printf("i:%ld  0-%ld  3 permute 1 none  hadamard time: %f ms\n", i, twoi, time_pass * 1000.f);

        //gettimeofday(&start, NULL);
        for (size_t j = twoi; j <= twoi * 2 - 1; j++)
        {
            trlwe_dft_hadamard_sum(cdft1, c_dec_DFT[j - twoi], *(ptr->k0), N);
            trlwe_dft_hadamard_sum_automorphism(cdft2, c_dec_DFT[n + j - twoi * 2], *(ptr->tk1), N);
            trlwe_dft_hadamard_sum_automorphism(cdft3, c_dec_DFT[n + j - twoi - twoi * 2], *(ptr->tk2), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);
        }
        //gettimeofday(&end, NULL);
        //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
        //printf("i:%ld  %ld-%ld  2 permute 2 none  hadamard time: %f ms\n", i, twoi, twoi * 2, time_pass * 1000.f);

        //gettimeofday(&start, NULL);
        for (size_t j = twoi * 2; j <= twoi + twoi * 2 - 1; j++)
        {
            trlwe_dft_hadamard_sum(cdft1, c_dec_DFT[j - twoi], *(ptr->k0), N);
            trlwe_dft_hadamard_sum(cdft2, c_dec_DFT[j - twoi * 2], *(ptr->k1), N);
            trlwe_dft_hadamard_sum_automorphism(cdft3, c_dec_DFT[n + j - twoi - twoi * 2], *(ptr->tk2), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);
        }
        //gettimeofday(&end, NULL);
        //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
        //printf("i:%ld  %ld-%ld  1 permute 3 none  hadamard time: %f ms\n", i, twoi * 2, twoi * 3, time_pass * 1000.f);

        //gettimeofday(&start, NULL);
        for (size_t j = twoi + twoi * 2; j <= n - 1; j++)
        {
            trlwe_dft_hadamard_sum(cdft1, c_dec_DFT[j - twoi], *(ptr->k0), N);
            trlwe_dft_hadamard_sum(cdft2, c_dec_DFT[j - twoi * 2], *(ptr->k1), N);
            trlwe_dft_hadamard_sum(cdft3, c_dec_DFT[j - twoi - twoi * 2], *(ptr->k2), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);
        }
        //gettimeofday(&end, NULL);
        //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
        //printf("i:%ld  %ld-%d  0 permute 4 none  hadamard time: %f ms\n", i, twoi * 3, n, time_pass * 1000.f);

        //gettimeofday(&start, NULL);
        for (size_t j = 0; j < n; j++)
        {
            trlwe_from_DFT(c[j], c_DFT[j]);
        }
        //gettimeofday(&end, NULL);
        //ptr = ptr->next;
        //time_pass = end.tv_sec - start.tv_sec + (float)(end.tv_usec - start.tv_usec) / 1000000;
        //printf("i:%ld trlwe_from_DFT time: %f ms\n", i, time_pass * 1000.f);
    }
    free_trlwe(cdft1);
    free_trlwe(cdft2);
    free_trlwe(cdft3);
    free_trlwe(cdft4);
    //free_trlwe(cdft5);
    //free_trlwe(cdft6);
}

void IMPmul_negative_my(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT,
                        uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list)
{
    bsk_node *ptr = list;
    TRLWE_DFT cdft1 = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT cdft2 = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT cdft3 = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT cdft4 = trlwe_alloc_new_DFT_sample(k, N);
    //TRLWE_DFT cdft5 = trlwe_alloc_new_DFT_sample(k, N);
    //TRLWE_DFT cdft6 = trlwe_alloc_new_DFT_sample(k, N);

    for (size_t i = 0; i < lv / 2; i++)
    {
        uint64_t twoi = 1 << (2 * i);

        //decompose(c_dec, c, n, N, B, l, k);
        emp_decompose(c_dec, c, n, N, B);
        for (size_t j = 0; j < n; j++)
        {
            for (size_t z = 0; z < l; z++)
            {
                trlwe_to_DFT(c_dec_DFT[j][z], c_dec[j][z]);
            }
        }
        for (size_t j = 0; j <= n - twoi - twoi * 2 - 1; j++)
        {
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), n, N, l, k);
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2], *(ptr->k1), n, N, l, k);
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2], *(ptr->k2), n, N, l, k);
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

            trlwe_dft_hadamard_sum(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), N);
            trlwe_dft_hadamard_sum(cdft2, c_dec_DFT[j + twoi * 2], *(ptr->k1), N);
            trlwe_dft_hadamard_sum(cdft3, c_dec_DFT[j + twoi + twoi * 2], *(ptr->k2), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);

            // trlwe_DFT_add(cdft5, cdft1, cdft2);
            // trlwe_DFT_add(cdft6, cdft3, cdft4);
            // trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
        }
        for (size_t j = n - twoi - twoi * 2; j <= n - twoi * 2 - 1; j++)
        {
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), n, N, l, k);
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2], *(ptr->k1), n, N, l, k);
            // tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), n, N, l, k);
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

            trlwe_dft_hadamard_sum(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), N);
            trlwe_dft_hadamard_sum(cdft2, c_dec_DFT[j + twoi * 2], *(ptr->k1), N);
            trlwe_dft_hadamard_sum_automorphism(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);

            // trlwe_DFT_add(cdft5, cdft1, cdft2);
            // trlwe_DFT_add(cdft6, cdft3, cdft4);
            // trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
        }
        for (size_t j = n - twoi * 2; j <= n - twoi - 1; j++)
        {
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), n, N, l, k);
            // tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2 - n], *(ptr->tk1), n, N, l, k);
            // tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), n, N, l, k);
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

            trlwe_dft_hadamard_sum(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), N);
            trlwe_dft_hadamard_sum_automorphism(cdft2, c_dec_DFT[j + twoi * 2 - n], *(ptr->tk1), N);
            trlwe_dft_hadamard_sum_automorphism(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);

            // trlwe_DFT_add(cdft5, cdft1, cdft2);
            // trlwe_DFT_add(cdft6, cdft3, cdft4);
            // trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
        }
        for (size_t j = n - twoi; j <= n - 1; j++)
        {
            // tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi - n], *(ptr->tk0), n, N, l, k);
            // tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2 - n], *(ptr->tk1), n, N, l, k);
            // tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), n, N, l, k);
            // trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

            trlwe_dft_hadamard_sum_automorphism(cdft1, c_dec_DFT[j + twoi - n], *(ptr->tk0), N);
            trlwe_dft_hadamard_sum_automorphism(cdft2, c_dec_DFT[j + twoi * 2 - n], *(ptr->tk1), N);
            trlwe_dft_hadamard_sum_automorphism(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), N);
            trlwe_dft_hadamard_sum(cdft4, c_dec_DFT[j], *(ptr->k3), N);

            trlwe_dft_sum(c_DFT[j], cdft1, cdft2, cdft3, cdft4, N);

            // trlwe_DFT_add(cdft5, cdft1, cdft2);
            // trlwe_DFT_add(cdft6, cdft3, cdft4);
            // trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
        }
        for (size_t j = 0; j < n; j++)
        {
            trlwe_from_DFT(c[j], c_DFT[j]);
        }
        ptr = ptr->next;
    }
    free_trlwe(cdft1);
    free_trlwe(cdft2);
    free_trlwe(cdft3);
    free_trlwe(cdft4);
    //free_trlwe(cdft5);
    //free_trlwe(cdft6);
}

void IMPmul_positive(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT, 
uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list) {
  //clock_t start, end;
  //double ms_time;
 //start = clock();
  bsk_node *ptr = list;
  TRLWE_DFT cdft1 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft2 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft3 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft4 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft5 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft6 = trlwe_alloc_new_DFT_sample(k, N);

  //end = clock();
  //ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  //printf("imp+ decom+space time: %f ms\n",ms_time);

  for (size_t i = 0; i < lv / 2; i++) {
    uint64_t twoi = 1 << (2*i);
    decompose(c_dec, c, n, N, B, l, k);
    for (size_t j = 0; j < n; j++) {
      for (size_t z = 0; z < l; z++) {
        trlwe_to_DFT(c_dec_DFT[j][z], c_dec[j][z]);
      }
    }
  //end = clock();
  //ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  //printf("imp+ i = %lu, dft time: %f ms\n",i, ms_time);
//start = clock();

    for (size_t j = 0; j <= twoi - 1;j++){
//printf("j=%lu\n",j);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[n + j - twoi], *(ptr->tk0), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[n + j - twoi * 2], *(ptr->tk1), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[n + j - twoi - twoi * 2], *(ptr->tk2), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->tk3), n, N, l, k);

      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
    }

    for (size_t j = twoi; j <= twoi * 2 - 1; j++) {
//printf("j=%lu\n",j);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j - twoi], *(ptr->k0), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[n + j - twoi * 2], *(ptr->tk1), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[n + j - twoi - twoi * 2], *(ptr->tk2), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
    }

    for (size_t j = twoi * 2; j <= twoi + twoi * 2 - 1; j++) {
//printf("j=%lu\n",j);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j - twoi], *(ptr->k0), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j - twoi * 2], *(ptr->k1), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[n + j - twoi - twoi * 2], *(ptr->tk2), n, N, l, k); 
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k); 

      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6); 

    }

    for (size_t j = twoi + twoi * 2; j <= n - 1; j++) {
//printf("j=%lu\n",j);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j - twoi], *(ptr->k0), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j - twoi * 2], *(ptr->k1), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j - twoi - twoi * 2], *(ptr->k2), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
    }
//printf("imp5\n");
  //end = clock();
  //ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  //printf("imp+ i = %lu, 4 round time: %f ms\n",i, ms_time);
  //start = clock();
    for (size_t j = 0; j < n; j++) {
      trlwe_from_DFT(c[j], c_DFT[j]);
    }
//printf("imp6\n");
  //end = clock();
  //ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  //printf("imp+ i = %lu, ifft  time: %f ms\n",i, ms_time);
    ptr = ptr->next;
  }
  free_trlwe(cdft1); free_trlwe(cdft2); free_trlwe(cdft3);
  free_trlwe(cdft4); free_trlwe(cdft5); free_trlwe(cdft6);

}

void IMPmul_negative(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT, 
uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list) {

  bsk_node *ptr = list;
  TRLWE_DFT cdft1 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft2 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft3 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft4 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft5 = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT cdft6 = trlwe_alloc_new_DFT_sample(k, N);

  for (size_t i = 0; i < lv / 2; i++) {
    uint64_t twoi = 1 << (2*i);
    decompose(c_dec, c, n, N, B, l, k);
    //emp_decompose(c_dec, c, n, N, B);
    for (size_t j = 0; j < n; j++) {
      for (size_t z = 0; z < l; z++) {
        trlwe_to_DFT(c_dec_DFT[j][z], c_dec[j][z]);
      }
    }
    for (size_t j = 0; j <= n - twoi - twoi * 2 - 1;j++){
      trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2], *(ptr->k1), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2], *(ptr->k2), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);


      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
    }
    for (size_t j = n - twoi - twoi * 2; j <= n - twoi * 2 - 1; j++) {
      trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2], *(ptr->k1), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
    }
    for (size_t j = n - twoi * 2; j <= n - twoi - 1; j++) {
      trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi], *(ptr->k0), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2 - n], *(ptr->tk1), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), n, N, l, k); 
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k); 

      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6); 
    }
    for (size_t j = n - twoi; j <= n - 1; j++) {
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft1, c_dec_DFT[j + twoi - n], *(ptr->tk0), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft2, c_dec_DFT[j + twoi * 2 - n], *(ptr->tk1), n, N, l, k);
      tau_trgsw_DFT_mul_trlwe_dec_DFT(cdft3, c_dec_DFT[j + twoi + twoi * 2 - n], *(ptr->tk2), n, N, l, k);
      trgsw_DFT_mul_trlwe_dec_DFT(cdft4, c_dec_DFT[j], *(ptr->k3), n, N, l, k);

      trlwe_DFT_add(cdft5, cdft1, cdft2);
      trlwe_DFT_add(cdft6, cdft3, cdft4);
      trlwe_DFT_add(c_DFT[j], cdft5, cdft6);
    }
    for (size_t j = 0; j < n; j++) {
      trlwe_from_DFT(c[j], c_DFT[j]);
    }
    ptr = ptr->next;
  }
  free_trlwe(cdft1); free_trlwe(cdft2); free_trlwe(cdft3);
  free_trlwe(cdft4); free_trlwe(cdft5); free_trlwe(cdft6);
}

TRGSW meta(TLWE ct, Bootstrap_Key brk, TRLWE_KS_Key *auk, TRLWE_KS_Key rvk, 
uint32_t N, uint32_t n, uint32_t k, uint32_t B, uint32_t l, int pre) {
  assert(k == 1);

  for (size_t i = 0; i < n; i++) {
    ct->a[i] = l * torus2int(ct->a[i], log2(2*N/l));
  }
  ct->b = l * torus2int(ct->b, log2(2*N/l));

  TorusPolynomial accpoly = polynomial_new_torus_polynomial(N);
  uint32_t bi = ct->b;
  for (uint32_t i = 0; i < l; i++) {
    uint32_t index = (bi + i) % (2 * N);
    Torus coe = 1UL << (sizeof(Torus) * 8 - (i + 1) * B);
    if (index < N) {
      accpoly->coeffs[index] = coe;
    } else {
      accpoly->coeffs[index % N] = -coe;
    }
  }
  TRLWE acc = trlwe_new_noiseless_trivial_sample(accpoly, k, N);

  TRLWE rotated_tv = trlwe_alloc_new_sample(k, N);
  TRLWE_DFT tmp = trlwe_alloc_new_DFT_sample(k, N);
  for (size_t i = 0; i < n; i++){
    if(ct->a[i] != 0) {
      trlwe_mul_by_xai_minus_1(rotated_tv, acc, -(ct->a[i]));
      trgsw_mul_trlwe_DFT(tmp, rotated_tv, brk->s[i]);
      trlwe_from_DFT(rotated_tv, tmp);
      trlwe_addto(acc, rotated_tv);
    }
  }
  free_trlwe(rotated_tv);
  free_trlwe(tmp);

  TRGSW CT = trgsw_alloc_new_sample(l, B, k, N);
  TRLWE temp = trlwe_alloc_new_sample(k, N);
  for (size_t i = 0; i < l; i++) {
    if (i == 0) {
      trlwe_copy(temp, acc);
    }
    trlwe_mul_by_xai(temp, acc, -i);

    homo_trace(CT->samples[i + l], temp, N / l, auk);
    trlwe_vkeyswitch(CT->samples[i], CT->samples[i + l], rvk);

  }
  free_polynomial(accpoly);
  free_trlwe(acc);
  free_trlwe(temp);

  return CT;
}























