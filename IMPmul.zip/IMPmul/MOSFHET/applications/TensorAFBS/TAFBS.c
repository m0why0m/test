#include <mosfhet.h>
#include <time.h>
#include "function.h"


typedef struct {
    uint32_t phin;           // total length (power of 2)
    uint32_t k;              // block size (power of 2) = n / m^pnt_levels
    uint32_t m;              // radix
    uint32_t num_blocks;     // phin / k
    uint32_t pnt_levels;     // log2(num_blocks)
    Torus q;         // prime modulus, q ≡ 1 (mod 2 phin)
    Torus *zeta;     // precomputed roots: zeta[i] = ω^i mod q
} pnt_context_t;


// Modular multiplication
static inline Torus mul_mod(Torus a, Torus b, Torus q) {
    return (a * b) % q;
}

// Fast modular exponentiation
static Torus pow_mod(Torus base, Torus exp, Torus q) {
    Torus res = 1;
    base %= q;
    while (exp) {
        if (exp & 1) res = mul_mod(res, base, q);
        base = mul_mod(base, base, q);
        exp >>= 1;
    }
    return res;
}

static uint32_t fast_pow(uint32_t a, uint32_t b) {
  uint32_t res = 1;
  uint32_t base = a;
  uint32_t power = b;
  while (power > 0) {
    if (power & 1) res *= base;
    base *= base;
    power >>= 1;
  }
  return res;
}


// Check if x is power of two
static bool is_power_of_two(uint32_t x) {
    return x > 0 && (x & (x - 1)) == 0;
}

pnt_context_t* pnt_init(uint32_t phin, uint32_t m, uint32_t pnt_levels, Torus q, Torus g);
int pnt(TorusPolynomial out, TorusPolynomial in, pnt_context_t* ctx);
int ipnt(TorusPolynomial out, TorusPolynomial in, pnt_context_t* ctx);
void pnt_free(pnt_context_t* ctx);


pnt_context_t* pnt_init(uint32_t phin, uint32_t m, uint32_t pnt_levels, Torus q, Torus g) {
    // Validate parameters
    //if (!is_power_of_two(n)) return NULL;
    //if (!is_power_of_two(k)) return NULL;
    //if (k > n || n % k != 0) return NULL;
    //if (q == 0 || (q - 1) % (2 * (Torus)n) != 0) return NULL;

    pnt_context_t* ctx = (pnt_context_t*)malloc(sizeof(pnt_context_t));
    if (!ctx) return NULL;

    ctx->phin = phin;
    ctx->m = m;
    ctx->pnt_levels = pnt_levels;
    ctx->k = phin / fast_pow(m, pnt_levels);
    ctx->num_blocks = phin / ctx->k;
    ctx->q = q;

    ctx->zeta = (Torus*)malloc(phin * sizeof(Torus));
    if (!ctx->zeta) {
        free(ctx);
        return NULL;
    }

    Torus omega = g;

    // Precompute zeta table: zeta[i] = ω^i mod q
    ctx->zeta[0] = 1;
    for (int i = 1; i < phin; i++) {
        ctx->zeta[i] = mul_mod(ctx->zeta[i - 1], omega, q);
    }

    return ctx;
}

int pnt(TorusPolynomial out, TorusPolynomial in, pnt_context_t* ctx) {
    if (!ctx) return -1;

    const uint32_t phin = ctx->phin;
    const Torus q = ctx->q;

    // Copy input and apply bit-reversal
    polynomial_copy_torus_polynomial(out, in);

    // Apply first pnt_levels layers of NTT
    for (size_t level = 0; level < ctx->pnt_levels; level++) {
        int width = 1 << (level + 1);        // butterfly width
        int groups = phin / width;           // number of groups
        int step = phin >> (level + 1);      // root step
        Torus w = ctx->zeta[step];           // ω^step

        for (size_t g = 0; g < groups; g++) {
            Torus wk = 1;
            int base = g * width;
            for (size_t j = 0; j < width / 2; j++) {
                Torus t = mul_mod(wk, out->coeffs[base + j + width / 2], q);
                Torus u = out->coeffs[base + j];
                out->coeffs[base + j] = (u + t) % q;
                out->coeffs[base + j + width / 2] = (u + q - t) % q;
                wk = mul_mod(wk, w, q);
            }
        }
    }

    return 0;
}

int ipnt(TorusPolynomial out, TorusPolynomial in, pnt_context_t* ctx) {
    if (!ctx) return -1;

    const uint32_t phin = ctx->phin;
    const Torus q = ctx->q;
    const uint32_t num_blocks = ctx->num_blocks;

    // Copy input
    polynomial_copy_torus_polynomial(out, in);

    // Inverse butterfly layers (reverse order)
    for (int level = ctx->pnt_levels - 1; level >= 0; level--) {
        uint32_t width = 1 << (level + 1);
        uint32_t groups = phin / width;
        uint32_t step = phin >> (level + 1);
        Torus w = ctx->zeta[step];
        Torus inv_w = pow_mod(w, q - 2, q);  // inverse by Fermat
        for (size_t g = 0; g < groups; g++) {
            Torus w_inv_k = 1;
            uint32_t base = g * width;
            for (size_t j = 0; j < width / 2; j++) {
                Torus u = out->coeffs[base + j];
                Torus v = out->coeffs[base + j + width / 2];

                Torus x = (u + v) % q;
                Torus y = (u + q - v) % q;
                y = mul_mod(y, w_inv_k, q);

                out->coeffs[base + j] = x;
                out->coeffs[base + j + width / 2] = y;

                w_inv_k = mul_mod(w_inv_k, inv_w, q);
            }
        }
    }

    // Final bit-reversal
    //bit_reverse(poly3, n);

    // Scale by 1/(n/k) = k/n
    Torus inv_scale = pow_mod(num_blocks, q - 2, q);
    for (size_t i = 0; i < phin; i++) {
        out->coeffs[i] = mul_mod(out->coeffs[i], inv_scale, q);
    }

    return 0;
}

void pnt_free(pnt_context_t* ctx) {
    if (ctx) {
        if (ctx->zeta) {
            free(ctx->zeta);
        }
        free(ctx);
    }
}
int main() {
    uint32_t phin = 512, m = 8, rho = 2;
    Torus q = 12289;
    Torus g = 3;

    //17 = 2^4+1, g = 5, k = 8
    //41 = 5*2^3+1, g = 6, k = 4   
    //73 = 9*2^3+1. g = 5, k = 4
    //97 = 3*2^5+1, g = 7, k = 16
    //137 = 17*2^3, g = 10, k = 4
    //193 = 3*2^6+1, g = 11, k = 32  
    //257 = 2^8+1, g = 3, k = 128

    //12289 , g = 3, k = 

    //73*193 = 14089 = 1761*2^3+1, g = , n = 4//
    //
    //17*257 = 273*2^4+1, g = 260, k = 8
    pnt_context_t *ctx = pnt_init(phin, m, rho, q, g);
    if (!ctx) {
        printf("Error: pnt_init failed.\n");
        return 1;
    }

    TorusPolynomial poly = polynomial_new_torus_polynomial(phin);
    TorusPolynomial poly2 = polynomial_new_torus_polynomial(phin);
    TorusPolynomial poly3 = polynomial_new_torus_polynomial(phin);
    for (size_t i = 0; i < phin; i++) {
        poly->coeffs[i] = i;
    }

    printf("Original: ");
    for (size_t i = 0; i < phin; i++) printf("%lu ", poly->coeffs[i]); 
    printf("\n");

    pnt(poly2, poly, ctx);
    printf("PNT:      ");
    for (size_t i = 0; i < phin; i++) printf("%lu ", poly2->coeffs[i]); 
    printf("\n");

    ipnt(poly3, poly2, ctx);
    printf("iPNT:     ");
    for (size_t i = 0; i < phin; i++) 
      printf("%lu ", poly3->coeffs[i]); 

    printf("\n");

    int ok = 1;
    for (size_t i = 0; i < phin; i++) {
        if (poly3->coeffs[i] != poly->coeffs[i]) {
            ok = 0; break;
        }
    }
    printf("Recovery: %s\n", ok ? "SUCCESS" : "FAILED");

    pnt_free(ctx);
    free_polynomial(poly);
    free_polynomial(poly2);
    free_polynomial(poly3);
    return 0;
}/*


int main(int argc, char const *argv[]) {

  const uint32_t N = 2048, n = 1024, k = 1, h = 128, hN = 256;
  const uint32_t kp = 16;
  const uint32_t l = 2, B = 20, l_auk = 1, B_auk = 23;
  const double key_sigma_phin = 0.0, key_sigma_N = 0.0;
  int pre = 5;


  uint32_t p = 1 << pre;
  const uint32_t phin = n / 2;
  int t = 5, base_bit = 3;


  srandom(time(NULL));
  TorusPolynomial m = polynomial_new_torus_polynomial(phin);
  for(size_t i = 0; i < n; i++) {
     //uint32_t mi = random() % (1 << pre);
     m->coeffs[i] = int2torus(1, pre);
  }

  TRLWE_Key rlwe_key_phin = trlwe_new_binary_key_with_hw(phin, h, key_sigma_phin);

  TRLWE rlwe_phin = trlwe_new_sample_(m, rlwe_key_phin);

  
  TorusPolynomial *z_pnt = PNT(rlwe_key_phin->s, phin, kp);


  clock_t t1, t2;
  double ms_time;
  printf("TensorAFBS ...\n");
  t1 = clock();

  TorusPolynomial *a_pnt = PNT(rlwe_phin->a[0], phin, kp);
  TorusPolynomial *b_pnt = PNT(rlwe_phin->b, phin, kp);



  t2 = clock();
  ms_time = ((double)(t2 - t1)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);

  

  printf("Releasing memory ... ");

  free_array_of_polynomials(a_pnt);
  free_array_of_polynomials(b_pnt);
  free_array_of_polynomials(z_pnt);

  printf("complete.\n");

  return 0;
}*/



















