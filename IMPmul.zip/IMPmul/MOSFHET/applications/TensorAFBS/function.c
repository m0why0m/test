#include <mosfhet.h>
#include "function.h"
#include <time.h>
#include <sys/time.h>

bsk_list create_bsk_list(uint32_t lv, int *rows,
TRGSW_DFT *bsk[4][4], TRGSW_DFT *tau_bsk[4][4]) {
  bsk_list res = (bsk_list)malloc(sizeof(bsk_node));
  bsk_node *ptr = res, *qtr;
  ptr->k0 = bsk[rows[0]][0]; ptr->k1 = bsk[rows[0]][1];
  ptr->k2 = bsk[rows[0]][2]; ptr->k3 = bsk[rows[0]][3];
  ptr->tk0 = tau_bsk[rows[0]][0]; ptr->tk1 = tau_bsk[rows[0]][1];
  ptr->tk2 = tau_bsk[rows[0]][2]; ptr->tk3 = tau_bsk[rows[0]][3];
  ptr->next = NULL;
  for (size_t i = 1; i < lv; i++) {
    qtr = (bsk_list)malloc(sizeof(bsk_node));
    ptr->next = qtr;
    ptr = ptr->next;
    ptr->next = NULL;
    qtr = NULL;
    ptr->k0 = bsk[rows[i]][0]; ptr->k1 = bsk[rows[i]][1];
    ptr->k2 = bsk[rows[i]][2]; ptr->k3 = bsk[rows[i]][3];
    ptr->tk0 = tau_bsk[rows[i]][0]; ptr->tk1 = tau_bsk[rows[i]][1];
    ptr->tk2 = tau_bsk[rows[i]][2]; ptr->tk3 = tau_bsk[rows[i]][3];

  }
  return res;
}

void delete_bsk_list(bsk_list list) {
  assert(list != NULL);
  bsk_node *ptr = list, *qtr;
  while (ptr->next != NULL) {
    qtr = ptr->next;
    ptr->next = qtr->next;
    free(qtr);
  }
  free(ptr);
}

bsk_head_list create_bsk_head_list(uint32_t diffnum, uint32_t *all_lv, int **all_rows,
TRGSW_DFT *bsk[4][4], TRGSW_DFT *tau_bsk[4][4]) {
  bsk_head_list res = (bsk_head_list)malloc(sizeof(bsk_head_node));
  bsk_head_node *ptr = res, *qtr;
  ptr->value = create_bsk_list(all_lv[0], all_rows[0], bsk, tau_bsk);
  ptr->next = NULL;
  for (size_t i = 1; i < diffnum; i++) {
    qtr = (bsk_head_list)malloc(sizeof(bsk_head_node));
    ptr->next = qtr;
    ptr = ptr-> next;
    ptr->next = NULL;
    qtr = NULL;
    ptr->value = create_bsk_list(all_lv[i], all_rows[i], bsk, tau_bsk);
  }
  return res;
}

void delete_bsk_head_list(bsk_head_list list) {
  assert(list != NULL);
  bsk_head_node *ptr = list, *qtr;
  while (ptr->next != NULL) {
    qtr = ptr->next;
    ptr->next = qtr->next;
    delete_bsk_list(qtr->value);
    free(qtr);
  }
  delete_bsk_list(ptr->value);
  free(ptr);
}

void tau_trgsw_monomial_sample(TRGSW out, int64_t m, int e, TRGSW_Key key) {
  const int l = key->l, Bg_bit = key->Bg_bit, N = key->trlwe_key->s[0]->N;
  assert(key->trlwe_key->k == 1);
  if (e&N) {
    m *= -1;
  }
  e &= (N - 1);
  for (size_t i = l; i < 2 * l; i++) {
    trlwe_sample(out->samples[i], NULL, key->trlwe_key);
  }
  TorusPolynomial tau_s = polynomial_new_torus_polynomial(N);
  TorusPolynomial tau_smB = polynomial_new_torus_polynomial(N);
  TorusPolynomial _tau_smB = polynomial_new_torus_polynomial(N);
  TorusPolynomial zero = polynomial_new_torus_polynomial(N);
  polynomial_permute(tau_s, *(key->trlwe_key->s), -1);
  for (size_t i = 0; i < l; i++) {
    const Torus h = 1UL << (sizeof(Torus) * 8 - (i + 1) * Bg_bit);
    for (size_t j = 0; j < N; j++) {
      tau_smB->coeffs[j] = tau_s->coeffs[j] * m * h;
    }
    polynomial_sub_torus_polynomials(_tau_smB, zero, tau_smB);
    trlwe_sample(out->samples[i], _tau_smB, key->trlwe_key);
    out->samples[l + i]->b->coeffs[e] += m * h;
  }
  free_polynomial(tau_s);
  free_polynomial(tau_smB);
  free_polynomial(_tau_smB);
  free_polynomial(zero);
}

TRGSW tau_trgsw_new_monomial_sample(int64_t m, int e, TRGSW_Key key) {
  const int l = key->l, k = key->trlwe_key->k, Bg_bit = key->Bg_bit, N = key->trlwe_key->s[0]->N;
  TRGSW res = trgsw_alloc_new_sample(l, Bg_bit, k, N);
  tau_trgsw_monomial_sample(res, m, e, key);
  return res;
}

TRGSW tau_trgsw_new_sample(Torus m, TRGSW_Key key) {
  return tau_trgsw_new_monomial_sample(m, 0, key);
}

TRLWE trlwe_new_sample_(TorusPolynomial m, TRLWE_Key key) {
  const int N = key->s[0]->N;
  Torus max = sizeof(Torus) == sizeof(uint64_t) ? UINT64_MAX : UINT32_MAX;
  TRLWE res = trlwe_alloc_new_sample(key->k, N);
  srandom(time(NULL));
  for (size_t i = 0; i < key->k; i++) {
    for (size_t j = 0; j < N; j++) {
      res->a[i]->coeffs[j] = random() % max;
    }
  }
  generate_torus_normal_random_array(res->b->coeffs, key->sigma, N);
  for (size_t i = 0; i < key->k; i++) {
    polynomial_mul_addto_torus(res->b, res->a[i], key->s[i]);
  }
  if (m != NULL) {
    for (size_t i = 0; i < m->N; i++) {
      res->b->coeffs[i] += m->coeffs[i];
    }
  }
  return res;
}


void gen_sparse_binary_array(uint64_t *out, uint64_t size, uint64_t h) {
  uint32_t max = floor(size / h) - 1;
  memset(out, 0, sizeof(uint64_t) * size);
  srandom(time(NULL));

  uint32_t index = 0, dis;
  for (size_t i = 0; i < h; i++) {
    dis = (random() % max) + 1;
    index += dis;
    out[index] = 1;
  }
}

TLWE_Key tlwe_new_binary_key_with_hw(int N, int h, double sigma) {
  TLWE_Key res = tlwe_alloc_key(N, sigma);
  gen_sparse_binary_array(res->s, N, h);
  return res;
}

TRLWE_Key trlwe_new_binary_key_with_hw(int N, int k, int h, double sigma) {
  TRLWE_Key res = trlwe_alloc_key(N, k, sigma);
  for (size_t i = 0; i < k; i++) {
    gen_sparse_binary_array(res->s[i]->coeffs, N, h);
    polynomial_torus_to_DFT(res->s_dft[i], res->s[i]);
  }
  return res;
}

TRLWE_Key trlwe_new_binary_key_with_hw_balance(int N, int k, int h, int bound, double sigma) {
  uint32_t block_size = bound;
  srandom(time(NULL));
  int index, maxindex = 0;
  TRLWE_Key res = trlwe_alloc_key(N, k, sigma);
  for (size_t i = 0; i < k; i++) {
    for (size_t j = 0; j < h; j++) {
      index = random() % block_size;
      maxindex += index;
      res->s[i]->coeffs[maxindex] = 1;
    }
    polynomial_torus_to_DFT(res->s_dft[i], res->s[i]);
  }
  return res;
}



void homo_trace(TRLWE out, TRLWE in, uint32_t n, TRLWE_KS_Key *auk) {
  uint32_t N = in->b->N, k = in->k;
  assert(k == 1);
  TRLWE temp = trlwe_alloc_new_sample(k, N);
  trlwe_copy(out, in);
  for (size_t i = log2(n) + 1; i <= log2(N); i++) {
    //mod switch
    for (size_t z = 0; z < N; z++) {
      out->a[0]->coeffs[z] /= 2;
    }
    for (size_t z = 0; z < N; z++) {
      out->b->coeffs[z] /= 2;
    }
    //homo auto
    uint32_t gen = (1 << i) + 1;
    trlwe_eval_automorphism(temp, out, gen, auk[1 << (i-1)]);
    trlwe_addto(temp, out);
    trlwe_copy(out, temp);
  }
  free_trlwe(temp);
}



void trlwe_vkeyswitch(TRLWE out, TRLWE in, TRLWE_KS_Key ks_key) {
  const int N = out->b->N;
  assert(out->k == ks_key->s[0][0]->k);
  assert(out->b->N == ks_key->s[0][0]->b->N);
  assert(k == 1);
  
  TorusPolynomial dec_in_a = polynomial_new_torus_polynomial(N);
  DFT_Polynomial tmp = polynomial_new_DFT_polynomial(N);
  TRLWE_DFT acc = trlwe_alloc_new_DFT_sample(out->k, N);
  TRLWE as = trlwe_alloc_new_sample(out->k, N);

  for (size_t i = 0; i < out->k; i++){
    for (size_t j = 0; j < N; j++) acc->a[i]->coeffs[j] = 0.;
  }
  for (size_t j = 0; j < N; j++) acc->b->coeffs[j] = 0.;
  
  for (size_t i = 0; i < in->k; i++){
    for (size_t j = 0; j < ks_key->t; j++){
      polynomial_decompose_i(dec_in_a, in->a[i], ks_key->base_bit, ks_key->t, j);
      polynomial_torus_to_DFT(tmp, dec_in_a);
      trlwe_DFT_mul_addto_by_polynomial(acc, ks_key->s[i][j], tmp);   
    }
  }
  trlwe_from_DFT(as, acc);
  memset(out->b->coeffs, 0, sizeof(Torus) * out->b->N);
  memcpy(out->a[0]->coeffs, in->b->coeffs, sizeof(Torus) * out->b->N);
  trlwe_addto(out, as);
  
  free_trlwe(acc);
  free_trlwe(as);
  free_polynomial(tmp);
  free_polynomial(dec_in_a);
}


void trgsw_mul_trlwe_b_DFT(TRLWE_DFT out, TorusPolynomial in1, TRGSW_DFT in2) {
  assert(in2->samples[0]->k == 1);
  const int N = in1->N, l = in2->l;

  TorusPolynomial dec_trlwe = polynomial_new_torus_polynomial(N);
  DFT_Polynomial dec_trlwe_DFT = polynomial_new_DFT_polynomial(N);

  polynomial_decompose_i(dec_trlwe, in1, in2->Bg_bit, in2->l, 0);
  polynomial_torus_to_DFT(dec_trlwe_DFT, dec_trlwe);
  polynomial_mul_DFT(out->a[0], dec_trlwe_DFT, in2->samples[l]->a[0]);
  polynomial_mul_DFT(out->b, dec_trlwe_DFT, in2->samples[l]->b);

  for (size_t j = 1; j < l; j++) {
    polynomial_decompose_i(dec_trlwe, in1, in2->Bg_bit, in2->l, j);
    polynomial_torus_to_DFT(dec_trlwe_DFT, dec_trlwe);
    polynomial_mul_addto_DFT(out->a[0], dec_trlwe_DFT, in2->samples[j + l]->a[0]);
    polynomial_mul_addto_DFT(out->b, dec_trlwe_DFT, in2->samples[j + l]->b);
  }

  free_polynomial(dec_trlwe);
  free_polynomial(dec_trlwe_DFT);
}


void decompose(TRLWE** c_dec, TRLWE* c, uint32_t n, uint32_t N, uint32_t B, uint32_t l, uint32_t k) {
  assert(k == 1);
  const int bit_size = sizeof(Torus) * 8;
  const uint64_t half_Bg = (1UL << (B - 1));
  const uint64_t h_mask = (1UL << B) - 1;
  uint64_t offset = 0;
  for (size_t i = 0; i < l; i++) {
    offset += (1UL << (bit_size - i * B - 1));
  }
  for (size_t h = 0; h < n; h++) {
    for (size_t i = 0; i < l; i++) {
      const uint64_t h_bit = bit_size - (i + 1) * B;
      for (size_t j = 0; j < N; j++) {
        const uint64_t coeff_off = c[h]->a[0]->coeffs[j] + offset;
        c_dec[h][i]->a[0]->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
      }
    }
    for (size_t i = 0; i < l; i++) {
      const uint64_t h_bit = bit_size - (i + 1) * B;
      for (size_t j = 0; j < N; j++) {
        const uint64_t coeff_off = c[h]->b->coeffs[j] + offset;
        c_dec[h][i]->b->coeffs[j] = ((coeff_off >> h_bit) & h_mask) - half_Bg;
      }
    }
  }
}

void polynomial_permute_DFT_inverse(DFT_Polynomial out, DFT_Polynomial in)
{
    uint32_t N = in->N;
    for (size_t i = 0; i < N / 2; i++)
    {
        out->coeffs[i] = in->coeffs[i];
    }
    for (size_t i = N / 2; i < N; i++)
    {
        out->coeffs[i] = -(in->coeffs[i]);
    }
}

void trgsw_DFT_mul_trlwe_dec_DFT(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2,
                                  uint32_t n, uint32_t N, uint32_t l, uint32_t k)
{
    assert(k == 1);
    polynomial_mul_DFT(out->a[0], in1[0]->a[0], in2->samples[0]->a[0]);
    polynomial_mul_DFT(out->b, in1[0]->a[0], in2->samples[0]->b);
    for (size_t j = 1; j < l; j++)
    {
        polynomial_mul_addto_DFT(out->a[0], in1[j]->a[0], in2->samples[j]->a[0]);
        polynomial_mul_addto_DFT(out->b, in1[j]->a[0], in2->samples[j]->b);
    }
    for (size_t j = 0; j < l; j++)
    {
        polynomial_mul_addto_DFT(out->a[0], in1[j]->b, in2->samples[j + l]->a[0]);
        polynomial_mul_addto_DFT(out->b, in1[j]->b, in2->samples[j + l]->b);
    }
}


void tau_trgsw_DFT_mul_trlwe_dec_DFT(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2,
                                      uint32_t n, uint32_t N, uint32_t l, uint32_t k)
{
    assert(k == 1);
    DFT_Polynomial poly = polynomial_new_DFT_polynomial(N);

    polynomial_permute_DFT_inverse(poly, in1[0]->a[0]);
    polynomial_mul_DFT(out->a[0], poly, in2->samples[0]->a[0]);
    polynomial_mul_DFT(out->b, poly, in2->samples[0]->b);

    for (size_t j = 1; j < l; j++)
    {

        polynomial_permute_DFT_inverse(poly, in1[j]->a[0]);
        polynomial_mul_addto_DFT(out->a[0], poly, in2->samples[j]->a[0]);
        polynomial_mul_addto_DFT(out->b, poly, in2->samples[j]->b);
    }
    for (size_t j = 0; j < l; j++)
    {

        polynomial_permute_DFT_inverse(poly, in1[j]->b);
        polynomial_mul_addto_DFT(out->a[0], poly, in2->samples[j + l]->a[0]);
        polynomial_mul_addto_DFT(out->b, poly, in2->samples[j + l]->b);
    }
    free_polynomial(poly);
}



















