#include <batchBoot.h>
#include <time.h>

void batch_circuit_bootstrap_TEP_process() {
  /* code */
  const uint32_t N = 2048, n = 1024, k = 1, h = 39, hN = 32;
  const uint32_t l_bsk = 2, B_bsk = 15, l_auk = 2, B_auk = 15;
  const uint32_t l_rvk = 2, B_rvk = 15, l_ = 4, B_ = 4;
  const double key_sigma = 2.989040792967434e-8, key_sigma_N = 2.2148688116005568e-16;
  int pre = 2;

/*
  const uint32_t N = 2048, n = 2048, k = 1, h = 39, hN = 28;
  const uint32_t l_bsk = 2, B_bsk = 15, l_auk = 2, B_auk = 15;
  const uint32_t l_rvk = 2, B_rvk = 15, l_ = 4, B_ = 4;
  const double key_sigma = pow(2,-53), key_sigma_N = pow(2,-53);
  int pre = 2;//pre = 4, hN <= 35; pre = 5, hN <= 28
*/

  const uint32_t beta = 2;
  int t = 5, base_bit = 3;
  uint32_t p = 1 << pre;
  uint32_t testP_num = fast_pow(p >> 1, beta - 1);

  TRLWE_Key rlwe_key_n = trlwe_new_binary_key_with_hw_balance(n, k, h, 64, key_sigma);
  TRLWE_Key rlwe_key_N = trlwe_new_binary_key_with_hw(N, k, hN, key_sigma_N);

  srandom(time(NULL));
  TorusPolynomial m = polynomial_new_torus_polynomial(n);
  for(size_t i = 0;i < n;i++) {
     uint32_t mi = random() % ((1 << pre) / 2);
     m->coeffs[i] = int2torus(mi, pre);
  }
  TRLWE rlwe = trlwe_new_sample_(m, rlwe_key_n);

  // printf("m(x) = (");
  // for (size_t i = 0; i < 8; i++) printf("%lu, ", torus2int(m->coeffs[i], pre));
  // printf(" ... ");
  // for (size_t i = n - 9; i < n; i++) printf("%lu, ", torus2int(m->coeffs[i], pre));
  // printf(")\n");

  uint64_t **f = (uint64_t **)malloc(sizeof(uint64_t *) * testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    f[i] = (uint64_t *)malloc(sizeof(uint64_t *) * N);
  }


  if (beta == 2 && p == 4) {
    //beta = 2, p = 4, testP_num = 2
    //[1,1,0,0],[0,0,1,1]
    for (size_t i = 0; i < N / 2; i++) {
      f[0][i] = 1; f[1][i] = 0;
    }
    for (size_t i = N / 2; i < N; i++) {
      f[0][i] = 0; f[1][i] = 1;
    }
  } else if (beta == 3 && p == 4) {
    //beta = 3, p = 4, testP_num = 4
    //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0]
    for (size_t i = 0; i < N / 2; i++) {
      f[0][i] = f[3][i] = 1; f[1][i] = f[2][i] = 0;
    }
    for (size_t i = N / 2; i < N; i++) {
      f[0][i] = f[3][i] = 0; f[1][i] = f[2][i] = 1;
    }
  } else if (beta == 4 && p == 4) {
    //beta = 4, p = 4, testP_num = 8
    //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0],[0,0,1,1],[1,1,0,0],[1,1,0,0],[0,0,1,1]
    for (size_t i = 0; i < N / 2; i++) {
      f[0][i] = f[3][i] = f[5][i] = f[6][i] = 1;
      f[1][i] = f[2][i] = f[4][i] = f[7][i] = 0;
    }
    for (size_t i = N / 2; i < N; i++) {
      f[0][i] = f[3][i] = f[5][i] = f[6][i] = 0;
      f[1][i] = f[2][i] = f[4][i] = f[7][i] = 1;
    }
  } else if (beta == 2 && p == 32) {
    //beta = 2, p = 32, testP_num = 16
    //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
    for (size_t i = 0; i < 16; i++) {
      for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
        f[0][j] = 15 - i;
      }
    }

    for (size_t i = 0; i < 16; i++) {//+i
      for (size_t ii = 0; ii < N; ii++) {
        f[i][ii] = func3(f[0][ii], i, p);
      }
    }
  } else if (beta == 3 && p == 32) {
    //beta = 3, p = 32, testP_num = 256
    //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
    for (size_t i = 0; i < 16; i++) {
      for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
        f[0][j] = 15 - i;
      }
    }
    for (size_t i = 0; i < 16; i++) {//+i
      for (size_t j = 0; j < 16; j++) {//+j
        for (size_t ii = 0; ii < N; ii++) {
          f[16*i+j][ii] = func2(f[0][ii], i, j, p);
        }
      }
    }
  } else if (beta == 4 && p == 32) {
    //beta = 4, p = 32, testP_num = 4096
    //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
    for (size_t i = 0; i < 16; i++) {
      for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
        f[0][j] = 15 - i;
      }
    }
    for (size_t i = 0; i < 16; i++) {//+i
      for (size_t j = 0; j < 16; j++) {//+j
        for (size_t z = 0; z < 16; z++) {//+z
          for (size_t ii = 0; ii < N; ii++) {
            f[256*i+16*j+z][ii] = func(f[0][ii], i, j, z, p);
          }
        }
      }
    }
  }

  TorusPolynomial *testP = polynomial_new_array_of_torus_polynomials(N, testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    for (size_t j = 0; j < N; j++) {
      testP[i]->coeffs[j] = int2torus(-f[i][j], pre);
    }
  }

  uint32_t diffnum = 0;
  int *diff = (int *)malloc((n + 1) * sizeof(int));
  int *diff0 = (int *)malloc((n + 1) * sizeof(int));
  memset(diff0, 0, (n + 1));
  memset(diff, 0, (n + 1));
  for (size_t i = 0; i < n; i++) {
    if (rlwe_key_n->s[0]->coeffs[i] == 1) {
      diff0[diffnum] = i;
      diffnum++;
    }
  }

  diff[0] = diff0[0];
  for (size_t i = 1; i < diffnum; i++) {
    diff[i] = diff0[i] - diff0[i - 1];
  }
  diff[diffnum] = diff0[diffnum - 1];
  diffnum++;
  free(diff0);

  uint32_t all_lv[100] = {0};
  int **all_rows = (int **)malloc(sizeof(int *) * 100);
  for (size_t i = 0; i < 100; i++) all_rows[i] = (int *)malloc(sizeof(int) * 100);

  for (size_t i = 0; i < diffnum; i++) {
    while (diff[i] > 0) {
      all_rows[i][all_lv[i]++] = diff[i] % 4;
      diff[i] >>= 2;
    }
  }


  TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key_N, l_bsk, B_bsk);
  // TRGSW rgsw_enc_0 = trgsw_new_sample(0, rgsw_key); TRGSW rgsw_enc_1 = trgsw_new_sample(1, rgsw_key);
  // TRGSW tau_rgsw_enc_0 = tau_trgsw_new_sample(0, rgsw_key); TRGSW tau_rgsw_enc_1 = tau_trgsw_new_sample(1, rgsw_key);
  // TRGSW_DFT rgsw_enc_0_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // TRGSW_DFT rgsw_enc_1_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // TRGSW_DFT tau_rgsw_enc_0_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // TRGSW_DFT tau_rgsw_enc_1_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // trgsw_to_DFT(rgsw_enc_0_DFT, rgsw_enc_0); trgsw_to_DFT(rgsw_enc_1_DFT, rgsw_enc_1);
  // trgsw_to_DFT(tau_rgsw_enc_0_DFT, tau_rgsw_enc_0); trgsw_to_DFT(tau_rgsw_enc_1_DFT, tau_rgsw_enc_1);
  TRGSW_DFT *bsk[4][4] = {NULL};
  // bsk[0][0] = &rgsw_enc_0_DFT; bsk[0][1] = &rgsw_enc_0_DFT; bsk[0][2] = &rgsw_enc_0_DFT; bsk[0][3] = &rgsw_enc_1_DFT;
  // bsk[1][0] = &rgsw_enc_1_DFT; bsk[1][1] = &rgsw_enc_0_DFT; bsk[1][2] = &rgsw_enc_0_DFT; bsk[1][3] = &rgsw_enc_0_DFT;
  // bsk[2][0] = &rgsw_enc_0_DFT; bsk[2][1] = &rgsw_enc_1_DFT; bsk[2][2] = &rgsw_enc_0_DFT; bsk[2][3] = &rgsw_enc_0_DFT;
  // bsk[3][0] = &rgsw_enc_0_DFT; bsk[3][1] = &rgsw_enc_0_DFT; bsk[3][2] = &rgsw_enc_1_DFT; bsk[3][3] = &rgsw_enc_0_DFT;
  TRGSW_DFT *tau_bsk[4][4] = {NULL};
  TRGSW enc[4] = {0};
  TRGSW_DFT enc_dft[4] = {0};
  // tau_bsk[0][0] = &tau_rgsw_enc_0_DFT; tau_bsk[0][1] = &tau_rgsw_enc_0_DFT; tau_bsk[0][2] = &tau_rgsw_enc_0_DFT; tau_bsk[0][3] = &rgsw_enc_1_DFT;
  // tau_bsk[1][0] = &tau_rgsw_enc_1_DFT; tau_bsk[1][1] = &tau_rgsw_enc_0_DFT; tau_bsk[1][2] = &tau_rgsw_enc_0_DFT; tau_bsk[1][3] = &rgsw_enc_0_DFT;
  // tau_bsk[2][0] = &tau_rgsw_enc_0_DFT; tau_bsk[2][1] = &tau_rgsw_enc_1_DFT; tau_bsk[2][2] = &tau_rgsw_enc_0_DFT; tau_bsk[2][3] = &rgsw_enc_0_DFT;
  // tau_bsk[3][0] = &tau_rgsw_enc_0_DFT; tau_bsk[3][1] = &tau_rgsw_enc_0_DFT; tau_bsk[3][2] = &tau_rgsw_enc_1_DFT; tau_bsk[3][3] = &rgsw_enc_0_DFT;
  // free_trgsw(rgsw_enc_0); free_trgsw(rgsw_enc_1);
  // free_trgsw(tau_rgsw_enc_0); free_trgsw(tau_rgsw_enc_1);
  create_bsk(bsk, tau_bsk, enc, enc_dft, rgsw_key, l_bsk, B_bsk, k, N);

  bsk_head_list all_list = create_bsk_head_list(diffnum, all_lv, all_rows, bsk, tau_bsk);
  for (size_t i = 0; i < diffnum; i++) {
    all_lv[i] <<= 1;
  }

  TRLWE_Key s2 = trlwe_alloc_key(N, k, key_sigma_N);
  polynomial_naive_mul_torus(s2->s[0], rlwe_key_N->s[0], rlwe_key_N->s[0]);
  polynomial_torus_to_DFT(s2->s_dft[0], s2->s[0]);
  TRLWE_KS_Key rvk = trlwe_new_KS_key(rlwe_key_N, s2, l_rvk, B_rvk);
  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key_N, true, l_auk, B_auk);
  free_trlwe_key(s2);

  TLWE_Key lwe_key = tlwe_alloc_key(N, 0);
  trlwe_extract_tlwe_key(lwe_key, rlwe_key_N);
  TRLWE_KS_Key ks_key = trlwe_new_full_packing_KS_key(rlwe_key_N, lwe_key, t, base_bit);
  free_tlwe_key(lwe_key);


  clock_t start, end;
  double ms_time;
  start = clock();

  TRGSW *c_rgsw = batch_circuit_bootstrap(rlwe, auk, rvk, N, n, k, h, pre, 
diffnum, all_lv, all_list, l_bsk, B_bsk, l_auk, B_auk, l_rvk, B_rvk, l_, B_);

  TRGSW *c_rgsw2 = trgsw_alloc_new_sample_array(beta, l_, B_, k, N);
  for (size_t i = 0; i < beta; i++) {
    trgsw_copy(c_rgsw2[i], c_rgsw[i]);
  }

  TRLWE result = TEP(c_rgsw2, testP, ks_key, auk, rlwe_key_N, N, k, l_, B_, beta, pre, testP_num);
  end = clock();
  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);

  //Verify
  TorusPolynomial plain = polynomial_new_torus_polynomial(N);
  trlwe_phase(plain, result, rlwe_key_N);
  uint64_t expacted = 0;
  for (size_t i = 0; i < beta; i++) {
    expacted += torus2int(m->coeffs[i], pre);
  }
  expacted %= p >> 1;
  printf("expactd = %lu, output = %lu\n", expacted, torus2int(plain->coeffs[0], pre));
  free_polynomial(plain);

  delete_bsk_head_list(all_list);
  free(diff);
  free_trlwe(rlwe);
  free_polynomial(m);
  free_polynomial(result);
  free_trlwe_key(rlwe_key_n);
  free_trlwe_key(rlwe_key_N);
  free_trgsw_key(rgsw_key);

  free_array_of_polynomials(testP, testP_num);
  free_trgsw_array(c_rgsw2, beta);
  for (size_t i = 0; i < N; i++) {
    free_trlwe_ks_key(auk[i]);
  }
  free(auk);
  free_trlwe_ks_key(rvk);
  free_trlwe_ks_key(ks_key);
  for (size_t i = 0; i < 100; i++) {
    free(all_rows[i]);
  }
  free(all_rows);
  for (size_t i = 0; i < 4; i++) {
    free(enc_dft[i]);
  }

  return 0;
}