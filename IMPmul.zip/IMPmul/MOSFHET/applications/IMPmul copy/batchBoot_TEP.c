#include <batchBoot.h>
#include <time.h>


TRLWE TEP(TRGSW *c_rgsw, TorusPolynomial *testP, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk, 
TRLWE_Key rlwe_key,
uint32_t N, uint32_t k, uint32_t l, uint32_t B, uint32_t beta, int pre, uint32_t testP_num) {

  assert(k == 1);
  uint32_t p = 1 << pre;

  TRLWE *c_rlwe = trlwe_alloc_new_sample_array(testP_num, k, N);
  TRLWE *c_rlwe_pack = trlwe_alloc_new_sample_array(testP_num, k, N);
  TRLWE_DFT rlwetemp_DFT = trlwe_alloc_new_DFT_sample(k, N);
  TRGSW_DFT rgswtemp_DFT = trgsw_alloc_new_DFT_sample(l, B, k, N);
  uint32_t rlwe_num = testP_num;

  //X^(b + N / p)
  TRGSW rgswtemp = trgsw_alloc_new_sample(l, B, k, N);
  for (size_t i = 0; i < beta; i++) {
    trgsw_mul_by_xai(rgswtemp, c_rgsw[i], N / p);
    trgsw_copy(c_rgsw[i], rgswtemp);
  }
  free_trgsw(rgswtemp);

  trgsw_to_DFT(rgswtemp_DFT, c_rgsw[0]);
  for (size_t i = 0; i < rlwe_num; i++) {
    trgsw_mul_trlwe_b_DFT(rlwetemp_DFT, testP[i], rgswtemp_DFT);
    trlwe_from_DFT(c_rlwe[i], rlwetemp_DFT);
  }

  //first repacking
  rlwe_num = trlwe_all_repacking(c_rlwe_pack, c_rlwe, ks_key, auk, N, k, pre, rlwe_num);

  //mult polynomial
  TorusPolynomial poly = polynomial_new_torus_polynomial(N);
  DFT_Polynomial poly_DFT = polynomial_new_DFT_polynomial(N);
  for (size_t i = N / (p >> 1); i < N; i++) {
    poly->coeffs[i] = 0;
  }
  for (size_t i = 0; i < N / (p >> 1); i++) {
    poly->coeffs[i] = -1;
  }
  polynomial_torus_to_DFT(poly_DFT, poly);
  TRLWE_DFT trlwe_DFT = trlwe_alloc_new_DFT_sample(k, N);
  TRLWE_DFT trlwe2_DFT = trlwe_alloc_new_DFT_sample(k, N);
  for (size_t i = 0; i < rlwe_num; i++) {
    trlwe_to_DFT(trlwe_DFT, c_rlwe_pack[i]);
    trlwe_DFT_mul_by_polynomial(trlwe2_DFT, trlwe_DFT, poly_DFT);
    trlwe_from_DFT(c_rlwe_pack[i], trlwe2_DFT);
  }

  //2th to (beta-1)th external product + sparse packing, r = 1, ..., beta - 2
  for (size_t r = 1; r < beta - 1; r++) {
    //external product
    trgsw_to_DFT(rgswtemp_DFT, c_rgsw[r]);
    for (size_t i = 0; i < rlwe_num; i++) {
      trgsw_mul_trlwe_DFT(rlwetemp_DFT, c_rlwe_pack[i], rgswtemp_DFT);
      trlwe_from_DFT(c_rlwe[i], rlwetemp_DFT);
    }
    //repacking
    rlwe_num = trlwe_all_repacking(c_rlwe_pack, c_rlwe, ks_key, auk, N, k, pre, rlwe_num);

    //mul poly
    for (size_t i = N / (p >> 1); i < N; i++) {
      poly->coeffs[i] = 0;
    }
    for (size_t i = 0; i < N / (p >> 1); i++) {
      poly->coeffs[i] = -1;
    }
    polynomial_torus_to_DFT(poly_DFT, poly);
    TRLWE_DFT trlwe_DFT = trlwe_alloc_new_DFT_sample(k, N);
    TRLWE_DFT trlwe2_DFT = trlwe_alloc_new_DFT_sample(k, N);
    for (size_t i = 0; i < rlwe_num; i++) {
      trlwe_to_DFT(trlwe_DFT, c_rlwe_pack[i]);
      trlwe_DFT_mul_by_polynomial(trlwe2_DFT, trlwe_DFT, poly_DFT);
      trlwe_from_DFT(c_rlwe_pack[i], trlwe2_DFT);
    }
  }
  free_polynomial(poly);
  free_polynomial(poly_DFT);

  //last external product, r = beta - 1
  trgsw_to_DFT(rgswtemp_DFT, c_rgsw[beta - 1]);
  for (size_t i = 0; i < rlwe_num; i++) {
    trgsw_mul_trlwe_DFT(rlwetemp_DFT, c_rlwe_pack[0], rgswtemp_DFT);
    trlwe_from_DFT(c_rlwe[i], rlwetemp_DFT);
  }

  TRLWE res = trlwe_alloc_new_sample(k, N);
  trlwe_copy(res, c_rlwe[0]);

  free_trlwe_array(c_rlwe, testP_num);
  free_trlwe_array(c_rlwe_pack, testP_num);
  free_trlwe(rlwetemp_DFT);
  free_trgsw(rgswtemp_DFT);

  return res;
}

void TEP_process() {

  const uint32_t N = 2048, beta = 4, k = 1, h = 128;
  const uint32_t l = 2, B = 20, l_auk = 1, B_auk = 23;
  const double key_sigma = 0;
  int pre = 5;
  uint32_t p = 1 << pre;
  uint32_t testP_num = fast_pow(p >> 1, beta - 1);
  int t = 5, base_bit = 3;

  TRLWE_Key rlwe_key = trlwe_new_binary_key_with_hw(N, k, h, key_sigma);
  TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key, l, B);

  srandom(time(NULL));
  TRGSW *c_rgsw = trgsw_alloc_new_sample_array(beta, l, B, k, N);
  trgsw_monomial_sample(c_rgsw[0], 1, 1 * N / (p >> 1) , rgsw_key);
  trgsw_monomial_sample(c_rgsw[1], 1, 1 * N / (p >> 1) , rgsw_key);
  trgsw_monomial_sample(c_rgsw[2], 1, 1 * N / (p >> 1) , rgsw_key);
  trgsw_monomial_sample(c_rgsw[3], 1, 4 * N / (p >> 1) , rgsw_key);


  uint64_t **f = (uint64_t **)malloc(sizeof(uint64_t *) * testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    f[i] = (uint64_t *)malloc(sizeof(uint64_t *) * N);
  }

  if (beta == 2 && p == 4) {
    //beta = 2, p = 4, testP_num = 2
    //[1,1,0,0],[0,0,1,1]
    for (size_t i = 0; i < N / 2; i++) {
      f[0][i] = 1; f[1][i] = 0;
    }
    for (size_t i = N / 2; i < N; i++) {
      f[0][i] = 0; f[1][i] = 1;
    }
  } else if (beta == 3 && p == 4) {
    //beta = 3, p = 4, testP_num = 4
    //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0]
    for (size_t i = 0; i < N / 2; i++) {
      f[0][i] = f[3][i] = 1; f[1][i] = f[2][i] = 0;
    }
    for (size_t i = N / 2; i < N; i++) {
      f[0][i] = f[3][i] = 0; f[1][i] = f[2][i] = 1;
    }
  } else if (beta == 4 && p == 4) {
    //beta = 4, p = 4, testP_num = 8
    //[1,1,0,0],[0,0,1,1],[0,0,1,1],[1,1,0,0],[0,0,1,1],[1,1,0,0],[1,1,0,0],[0,0,1,1]
    for (size_t i = 0; i < N / 2; i++) {
      f[0][i] = f[3][i] = f[5][i] = f[6][i] = 1;
      f[1][i] = f[2][i] = f[4][i] = f[7][i] = 0;
    }
    for (size_t i = N / 2; i < N; i++) {
      f[0][i] = f[3][i] = f[5][i] = f[6][i] = 0;
      f[1][i] = f[2][i] = f[4][i] = f[7][i] = 1;
    }
  } else if (beta == 2 && p == 32) {
    //beta = 2, p = 32, testP_num = 16
    //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
    for (size_t i = 0; i < 16; i++) {
      for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
        f[0][j] = 15 - i;
      }
    }

    for (size_t i = 0; i < 16; i++) {//+i
      for (size_t ii = 0; ii < N; ii++) {
        f[i][ii] = func3(f[0][ii], i, p);
      }
    }
  } else if (beta == 3 && p == 32) {
    //beta = 3, p = 32, testP_num = 256
    //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
    for (size_t i = 0; i < 16; i++) {
      for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
        f[0][j] = 15 - i;
      }
    }
    for (size_t i = 0; i < 16; i++) {//+i
      for (size_t j = 0; j < 16; j++) {//+j
        for (size_t ii = 0; ii < N; ii++) {
          f[16*i+j][ii] = func2(f[0][ii], i, j, p);
        }
      }
    }
  } else if (beta == 4 && p == 32) {
    //beta = 4, p = 32, testP_num = 4096
    //[15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0]
    for (size_t i = 0; i < 16; i++) {
      for (size_t j = i * N / 16; j < (i + 1) * N / 16; j++) {
        f[0][j] = 15 - i;
      }
    }
    for (size_t i = 0; i < 16; i++) {//+i
      for (size_t j = 0; j < 16; j++) {//+j
        for (size_t z = 0; z < 16; z++) {//+z
          for (size_t ii = 0; ii < N; ii++) {
            f[256*i+16*j+z][ii] = func(f[0][ii], i, j, z, p);
          }
        }
      }
    }
  }


  TorusPolynomial *testP = polynomial_new_array_of_torus_polynomials(N, testP_num);
  for (size_t i = 0; i < testP_num; i++) {
    for (size_t j = 0; j < N; j++) {
      testP[i]->coeffs[j] = int2torus(-f[i][j], pre);
    }
  }

  TLWE_Key lwe_key = tlwe_alloc_key(N, 0);
  trlwe_extract_tlwe_key(lwe_key, rlwe_key);
  TRLWE_KS_Key ks_key = trlwe_new_full_packing_KS_key(rlwe_key, lwe_key, t, base_bit);
  free_tlwe_key(lwe_key);

  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key, true, l_auk, B_auk);

  
  clock_t start, end;
  double ms_time;
  start = clock();

  TRLWE result = TEP(c_rgsw, testP, ks_key, auk, rlwe_key, N, k, l, B, beta, pre, testP_num);

  end = clock();
  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;
  printf("time: %f ms\n", ms_time);

  TorusPolynomial plain = polynomial_new_torus_polynomial(N);
  trlwe_phase(plain, result, rlwe_key);
  printf("result = %lu\n", torus2int(plain->coeffs[0], pre));

  free_polynomial(plain);
  free_polynomial(result);
  free_array_of_polynomials(testP, testP_num);
  free_trgsw_array(c_rgsw, beta);
  free_trlwe_key(rlwe_key);
  free_trlwe_ks_key(ks_key);
  free_trgsw_key(rgsw_key);
  for (size_t i = 0; i < N; i++) free_trlwe_ks_key(auk[i]);
  free(auk);

  return 0;
}