#include <mosfhet.h>
#include <time.h>
#include "function.h"


int main(int argc, char const *argv[]) {
  /* code */
  const uint32_t N = 2048, n = 2048, k = 1, h = 39, hN = 28;
  const uint32_t l_bsk = 2, B_bsk = 15, l_auk = 2, B_auk = 15;
  const uint32_t l_rvk = 2, B_rvk = 15, l_ = 4, B_ = 4;
  const double key_sigma = pow(2,-53), key_sigma_N = pow(2,-53);
  int pre = 2;//pre = 4, hN <= 35; pre = 5, hN <= 28


  //const uint32_t N = 2048, n = 2048, k = 1, h = 39, hN = 8;
  //const uint32_t l_bsk = 4, B_bsk = 11, l_auk = 4, B_auk = 11;
  //const uint32_t l_rvk = 4, B_rvk = 11, l_ = 2, B_ = 20;
  //const double key_sigma = pow(2,-53), key_sigma_N = pow(2,-53);
  //int pre = 5;//pre = 4, hN <= 35; pre = 5, hN <= 28

  //printf("INIT: Preparing for secret key ... ");
  TRLWE_Key rlwe_key_n = trlwe_new_binary_key_with_hw_balance(n, k, h, 16, key_sigma);
  TRLWE_Key rlwe_key_N = trlwe_new_binary_key_with_hw(N, k, hN, key_sigma_N);
  //TRLWE_Key rlwe_key_N = trlwe_new_binary_key(N,k,key_sigma_N);
  //printf("complete.\n");

  //printf("INIT: Preparing for RLWE(m) ... ");
  srandom(time(NULL));
  TorusPolynomial m = polynomial_new_torus_polynomial(n);
  for(size_t i = 0;i < n;i++) {
     uint32_t mi = random() % ((1 << pre) / 2);
     m->coeffs[i] = int2torus(mi, pre);
  }
  TRLWE rlwe = trlwe_new_sample_(m, rlwe_key_n);
  //printf("complete.\n");

  // printf("m(x) = (");
  // for (size_t i = 0; i < 8; i++) printf("%lu, ", torus2int(m->coeffs[i], pre));
  // printf(" ... ");
  // for (size_t i = n - 9; i < n; i++) printf("%lu, ", torus2int(m->coeffs[i], pre));
  // printf(")\n");

  //printf("INIT: Decomposing secret key ... ");
  uint32_t diffnum = 0;
  int *diff = (int *)malloc((n + 1) * sizeof(int));
  int *diff0 = (int *)malloc((n + 1) * sizeof(int));
  memset(diff0, 0, (n + 1));
  memset(diff, 0, (n + 1));
  for (size_t i = 0; i < n; i++) {
    if (rlwe_key_n->s[0]->coeffs[i] == 1) {
      diff0[diffnum] = i;
      diffnum++;
    }
  }

  diff[0] = diff0[0];
  for (size_t i = 1; i < diffnum; i++) {
    diff[i] = diff0[i] - diff0[i - 1];
  }
  diff[diffnum] = diff0[diffnum - 1];
  diffnum++;
  free(diff0);

  uint32_t all_lv[100] = {0};
  int **all_rows = (int **)malloc(sizeof(int *) * 100);
  for (size_t i = 0; i < 100; i++) all_rows[i] = (int *)malloc(sizeof(int) * 100);

  for (size_t i = 0; i < diffnum; i++) {
    while (diff[i] > 0) {
      all_rows[i][all_lv[i]++] = diff[i] % 4;
      diff[i] >>= 2;
    }
  }

    TRGSW_Key rgsw_key = trgsw_new_key(rlwe_key_N, l_bsk, B_bsk);
  // TRGSW rgsw_enc_0 = trgsw_new_sample(0, rgsw_key); TRGSW rgsw_enc_1 = trgsw_new_sample(1, rgsw_key);
  // TRGSW tau_rgsw_enc_0 = tau_trgsw_new_sample(0, rgsw_key); TRGSW tau_rgsw_enc_1 = tau_trgsw_new_sample(1, rgsw_key);
  // TRGSW_DFT rgsw_enc_0_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // TRGSW_DFT rgsw_enc_1_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // TRGSW_DFT tau_rgsw_enc_0_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // TRGSW_DFT tau_rgsw_enc_1_DFT = trgsw_alloc_new_DFT_sample(l_bsk, B_bsk, k, N);
  // trgsw_to_DFT(rgsw_enc_0_DFT, rgsw_enc_0); trgsw_to_DFT(rgsw_enc_1_DFT, rgsw_enc_1);
  // trgsw_to_DFT(tau_rgsw_enc_0_DFT, tau_rgsw_enc_0); trgsw_to_DFT(tau_rgsw_enc_1_DFT, tau_rgsw_enc_1);
  TRGSW_DFT *bsk[4][4] = {NULL};
  // bsk[0][0] = &rgsw_enc_0_DFT; bsk[0][1] = &rgsw_enc_0_DFT; bsk[0][2] = &rgsw_enc_0_DFT; bsk[0][3] = &rgsw_enc_1_DFT;
  // bsk[1][0] = &rgsw_enc_1_DFT; bsk[1][1] = &rgsw_enc_0_DFT; bsk[1][2] = &rgsw_enc_0_DFT; bsk[1][3] = &rgsw_enc_0_DFT;
  // bsk[2][0] = &rgsw_enc_0_DFT; bsk[2][1] = &rgsw_enc_1_DFT; bsk[2][2] = &rgsw_enc_0_DFT; bsk[2][3] = &rgsw_enc_0_DFT;
  // bsk[3][0] = &rgsw_enc_0_DFT; bsk[3][1] = &rgsw_enc_0_DFT; bsk[3][2] = &rgsw_enc_1_DFT; bsk[3][3] = &rgsw_enc_0_DFT;
  TRGSW_DFT *tau_bsk[4][4] = {NULL};
  TRGSW enc[4] = {0};
  TRGSW_DFT enc_dft[4] = {0};
  // tau_bsk[0][0] = &tau_rgsw_enc_0_DFT; tau_bsk[0][1] = &tau_rgsw_enc_0_DFT; tau_bsk[0][2] = &tau_rgsw_enc_0_DFT; tau_bsk[0][3] = &rgsw_enc_1_DFT;
  // tau_bsk[1][0] = &tau_rgsw_enc_1_DFT; tau_bsk[1][1] = &tau_rgsw_enc_0_DFT; tau_bsk[1][2] = &tau_rgsw_enc_0_DFT; tau_bsk[1][3] = &rgsw_enc_0_DFT;
  // tau_bsk[2][0] = &tau_rgsw_enc_0_DFT; tau_bsk[2][1] = &tau_rgsw_enc_1_DFT; tau_bsk[2][2] = &tau_rgsw_enc_0_DFT; tau_bsk[2][3] = &rgsw_enc_0_DFT;
  // tau_bsk[3][0] = &tau_rgsw_enc_0_DFT; tau_bsk[3][1] = &tau_rgsw_enc_0_DFT; tau_bsk[3][2] = &tau_rgsw_enc_1_DFT; tau_bsk[3][3] = &rgsw_enc_0_DFT;
  // free_trgsw(rgsw_enc_0); free_trgsw(rgsw_enc_1);
  // free_trgsw(tau_rgsw_enc_0); free_trgsw(tau_rgsw_enc_1);
  create_bsk(bsk, tau_bsk, enc, enc_dft, rgsw_key, l_bsk, B_bsk, k, N);

  bsk_head_list all_list = create_bsk_head_list(diffnum, all_lv, all_rows, bsk, tau_bsk);
  for (size_t i = 0; i < diffnum; i++) {
    all_lv[i] <<= 1;
  }


  TRLWE_Key s2 = trlwe_alloc_key(N, k, key_sigma_N);
  polynomial_naive_mul_torus(s2->s[0], rlwe_key_N->s[0], rlwe_key_N->s[0]);
  polynomial_torus_to_DFT(s2->s_dft[0], s2->s[0]);
  TRLWE_KS_Key rvk = trlwe_new_KS_key(rlwe_key_N, s2, l_rvk, B_rvk);
  TRLWE_KS_Key *auk = trlwe_new_automorphism_KS_keyset(rlwe_key_N, true, l_auk, B_auk);
  free_trlwe_key(s2);


  clock_t start, end;
  double ms_time;
  start = clock();

  TRGSW *c_rgsw = batch_circuit_bootstrap(rlwe, auk, rvk,
N, n, k, h, l_bsk, B_bsk, pre, diffnum, all_lv, all_list, l_auk, B_auk, l_rvk, B_rvk, l_, B_);

  end = clock();
  ms_time = ((double)(end - start)) * 1000 / CLOCKS_PER_SEC;


  TorusPolynomial m1 = polynomial_new_torus_polynomial(N);
  for (size_t i = 0; i< N;i++) m1->coeffs[i] = 0;
  m1->coeffs[0] = int2torus(1,pre);
  TRLWE sample = trlwe_new_sample(m1, rlwe_key_N);
  TorusPolynomial pp = polynomial_new_torus_polynomial(N);
  for (size_t i = 0; i < n; i++) {
    TRGSW_DFT rgs = trgsw_alloc_new_DFT_sample(l_, B_,k,N);
    trgsw_to_DFT(rgs, c_rgsw[i]);
    TRLWE_DFT res = trlwe_alloc_new_DFT_sample(k, N);
    trgsw_mul_trlwe_DFT(res, sample, rgs);
    trlwe_DFT_phase(pp, res, rlwe_key_N);
    for (size_t j = 0; j < N; j++) {
      if (torus2int(pp->coeffs[j], pre) != 0) {
        printf("%lu-th ciphertext, index = %lu, value = %lu\n", i, j, torus2int(pp->coeffs[j], pre));
      }
    }
    free_trgsw(rgs);
    free_trlwe(res);
  }
  printf("time: %f ms\n", ms_time);
  free_polynomial(pp);
  free_polynomial(m1);
  free_trlwe(sample);

  //printf("Cleaning data ...");
  delete_bsk_head_list(all_list);
  free(diff);
  free_trlwe(rlwe);

  free_polynomial(m);
  free_trlwe_key(rlwe_key_n);
  free_trlwe_key(rlwe_key_N);
  free_trgsw_key(rgsw_key);



  for (size_t i = 0; i < N; i++) {
    free_trlwe_ks_key(auk[i]);
  }
  free(auk);
  free_trlwe_ks_key(rvk);
  for (size_t i = 0; i < 100; i++) {
    free(all_rows[i]);
  }
  free(all_rows);
  for (size_t i = 0; i < 4; i++) {
    free(enc_dft[i]);
  }

  //printf("complete.\n");

  return 0;
}



















