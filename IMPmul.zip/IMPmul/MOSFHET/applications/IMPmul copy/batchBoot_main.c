#include <batchBoot.h>
#include <time.h>

int main() {
    //test full case
    int choose = 2;
    /*choose: 2, 4, 6, 8 -> Boot_2, Boot_4, Boot_6, Boot_8*/
    /*choose: 1, 3, 5, 7 -> SBoot_2, SBoot_4, SBoot_6, SBoot_8*/
    batch_bootstrap_process(choose);


    //test batch circuit bootstrap
    batch_circuit_bootstrap_process();

    //test tree product
    TEP_process();

    //test batch circuit bootstrap with tree product
    batch_circuit_bootstrap_TEP_process();
    return 0;
}