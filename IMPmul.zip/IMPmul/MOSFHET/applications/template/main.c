#include <mosfhet.h>

int main(int argc, char const *argv[])
{
  /* code */
  printf("OK\n");
  return 0;
}
