#include <mosfhet.h>
#include <function.h>
#include <time.h>

TRLWE batch_bootstrap(TorusPolynomial m,TorusPolynomial testP, TRLWE rlwe, TRLWE_Key rlwe_key,
bsk_head_list all_list, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk,
uint32_t N, uint32_t n, uint32_t k, uint32_t h, uint32_t l, uint32_t B, int pre,
uint32_t diffnum, uint32_t *all_lv, int t, 
int base_bit);

TRGSW *batch_circuit_bootstrap(TRLWE rlwe,
TRLWE_KS_Key *htk, TRLWE_KS_Key rvk,
uint32_t N, uint32_t n, uint32_t k, uint32_t h, int pre,
uint32_t diffnum, uint32_t *all_lv, bsk_head_list all_list, uint32_t l_bsk, uint32_t B_bsk,
uint32_t l_auk, uint32_t B_auk, uint32_t l_rvk, uint32_t B_rvk,
uint32_t l_, uint32_t B_);

TRLWE TEP(TRGSW *c_rgsw, TorusPolynomial *testP, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk, TRLWE_Key rlwe_key, 
  uint32_t N, uint32_t k, uint32_t l, uint32_t B, uint32_t beta, int pre, uint32_t testP_num);

void batch_bootstrap_process(int choose);
void batch_circuit_bootstrap_process();
void TEP_process();
void batch_circuit_bootstrap_TEP_process();
