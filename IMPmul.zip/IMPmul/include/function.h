#include <mosfhet.h>

typedef struct bsk_node {
  TRGSW_DFT *k0, *k1, *k2, *k3;
  TRGSW_DFT *tk0, *tk1, *tk2, *tk3;
  struct bsk_node *next;
} bsk_node, *bsk_list;

typedef struct bsk_head_node {
  bsk_list value;
  struct bsk_head_node *next;
} bsk_head_node, *bsk_head_list;

bsk_list create_bsk_list(uint32_t lv, int *rows, TRGSW_DFT *bsk[4][4], TRGSW_DFT *tau_bsk[4][4]);
bsk_head_list create_bsk_head_list(uint32_t diffnum, uint32_t *all_lv, int **all_rows, TRGSW_DFT *bsk[4][4], TRGSW_DFT *tau_bsk[4][4]);

void delete_bsk_list(bsk_list list);
void delete_bsk_head_list(bsk_head_list list);

void tau_trgsw_monomial_sample(TRGSW out, int64_t m, int e, TRGSW_Key key);
TRGSW tau_trgsw_new_monomial_sample(int64_t m, int e, TRGSW_Key key);
TRGSW tau_trgsw_new_sample(Torus m, TRGSW_Key key);

TRLWE trlwe_new_sample_(TorusPolynomial m, TRLWE_Key key);

void polynomial_permute_DFT_inverse(DFT_Polynomial out, DFT_Polynomial in);

void gen_sparse_binary_array(uint64_t *out, uint64_t size, uint64_t h);

TLWE_Key tlwe_new_binary_key_with_hw(int N, int h, double sigma);
TRLWE_Key trlwe_new_binary_key_with_hw(int N, int k, int h, double sigma);
TRLWE_Key trlwe_new_binary_key_with_hw_balance(int N, int k, int h, int bound, double sigma);

void homo_trace(TRLWE out, TRLWE in, uint32_t n, TRLWE_KS_Key *auk);
void trlwe_vkeyswitch(TRLWE out, TRLWE in, TRLWE_KS_Key ks_key);

void trgsw_mul_trlwe_b_DFT(TRLWE_DFT out, TorusPolynomial in1, TRGSW_DFT in2);

uint32_t fast_pow(uint32_t a, uint32_t b);

void trlwe_repacking(TRLWE c_pack, TRLWE *c_rlwe, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk, 
  uint32_t N, uint32_t k, uint32_t n);

uint32_t trlwe_all_repacking(TRLWE *c_rlwe_pack, TRLWE *c_rlwe, TRLWE_KS_Key ks_key, TRLWE_KS_Key *auk, 
  uint32_t N, uint32_t k, int pre, uint32_t rlwe_num);

void polynomial_permute_DFT_inverse(DFT_Polynomial out, DFT_Polynomial in);

void decompose1(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B, uint32_t l, uint32_t k);
void decompose(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B, uint32_t l, uint32_t k);
void emp_decompose1(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B);
void emp_decompose2(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B);
void emp_decompose3(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B);
void emp_decompose(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B);
void emp_decompose4(TRLWE **c_dec, TRLWE *c, uint32_t n, uint32_t N, uint32_t B);

void trgsw_DFT_mul_trlwe_dec_DFT1(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t n, uint32_t N, uint32_t l, uint32_t k);
void trgsw_DFT_mul_trlwe_dec_DFT(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t n, uint32_t N, uint32_t l, uint32_t k);
void tau_trgsw_DFT_mul_trlwe_dec_DFT1(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t n, uint32_t N, uint32_t l, uint32_t k);
void tau_trgsw_DFT_mul_trlwe_dec_DFT(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t n, uint32_t N, uint32_t l, uint32_t k);
void trlwe_dft_hadamard_sum(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t N);
void trlwe_dft_hadamard_sum_automorphism(TRLWE_DFT out, TRLWE_DFT *in1, TRGSW_DFT in2, uint32_t N);
void trlwe_dft_sum1(TRLWE_DFT out, TRLWE_DFT in1, TRLWE_DFT in2, TRLWE_DFT in3, TRLWE_DFT in4, uint32_t N);
void trlwe_dft_sum(TRLWE_DFT out, TRLWE_DFT in1, TRLWE_DFT in2, TRLWE_DFT in3, TRLWE_DFT in4, uint32_t N);


void IMPmul_positive_my(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT,
                        uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list);
void IMPmul_positive(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT,
                     uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list);
void IMPmul_negative_my(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT,
                        uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list);
void IMPmul_negative(TRLWE *c, TRLWE **c_dec, TRLWE_DFT *c_DFT, TRLWE_DFT **c_dec_DFT,
                     uint32_t N, uint32_t n, uint32_t k, uint32_t l, uint32_t B, uint32_t lv, bsk_list list);


void create_bsk(TRGSW_DFT *bsk[4][4], TRGSW_DFT *tau_bsk[4][4], TRGSW *enc, TRGSW_DFT *enc_dft, TRGSW_Key rgsw_key,
uint32_t l_bsk, uint32_t B_bsk, uint32_t k, uint32_t N);


uint64_t func(uint64_t a1, uint64_t a2, uint64_t a3, uint64_t a4, uint32_t p);
uint64_t func2(uint64_t a1, uint64_t a2, uint64_t a3, uint32_t p);
uint64_t func3(uint64_t a1, uint64_t a2, uint32_t p);









